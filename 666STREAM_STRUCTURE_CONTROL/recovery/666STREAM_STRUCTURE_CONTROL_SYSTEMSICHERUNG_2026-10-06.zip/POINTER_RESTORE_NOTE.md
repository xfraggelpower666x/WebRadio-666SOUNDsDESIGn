# Pointer Restore Note

This package is a BODY backup bound to source body HEAD:
ad55b98c38f0bb3185860d223ba8ed1ae8eb8c14

CURRENT_POINTER.json is intentionally excluded.
After restore, perform direct repository readback and publish CURRENT_POINTER last.
The ZIP itself is not current authority.
Newer valid evolution must not be replaced by this backup.
