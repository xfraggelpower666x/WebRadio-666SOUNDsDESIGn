666SOUNDsDESIGn MUSIC SYSTEM
===========================

Purpose
-------
This pack is a structured production system for:
- Suno song generation
- lyric archiving
- radio/web radio intros
- voiceover scripting
- dark psytrance / techno workflows
- reusable song factory templates

Quick Start
-----------
1. Copy a template from 01_SONG_FACTORY/templates
2. Fill in lyrics, styleprompt, BPM, voice, structure
3. Use 02_SUNO_PROMPTS templates to create generation prompts
4. Use 03_RADIO_INTROS and 04_VOICEOVER for station content
5. Use 05_GENRE_PRESETS for fast setup
6. Track projects in 08_PROJECT_INDEX/project_tracker.txt
