666SOUNDsDESIGn – PRODUCER PACK README
======================================

This package is designed as a Producer / AI Song Development Pack
for electronic music production, especially Psytrance, DJ tools,
and AI‑assisted songwriting.

Folder Structure
----------------

/lyrics
Contains all archived lyrics. Each file represents one song idea
or track concept.

/styleprompts
Contains production style prompts used with:
- Suno
- AI music engines
- Prompt‑driven music generation
- DAW reference notes

/archive_sort_prompt.txt
This is the Archive Sort System Prompt used to automatically
organize lyrics and style prompts in ChatGPT.

How the Sorting System Works
----------------------------

1. Paste the prompt from archive_sort_prompt.txt into a new ChatGPT chat.
2. Each message you send becomes a new song entry.
3. The system automatically:
   - assigns an entry number
   - detects or generates a title
   - separates lyrics and style prompts
4. The output becomes a structured archive ready for production.

Example Workflow
----------------

1. Open a new ChatGPT chat
2. Paste archive_sort_prompt.txt
3. Insert lyrics like:

   Psytrance
   Feel the power
   Psytrance
   A beast awakening
   Hard Dark Psytrance 145 BPM

4. The system returns:

   ENTRY XX
   TITLE
   LYRICS
   STYLE PROMPT

Future Extensions
-----------------

MP3 Recognition System
- Extract lyrics from recorded audio
- Speech‑to‑text lyric detection
- Automatic lyric archive creation

Lyrics Extraction Engine
- Analyze MP3 files
- Detect spoken or sung vocals
- Convert to lyric entries

Song Database
- Structured storage with fields:
  TITLE
  BPM
  GENRE
  LYRICS
  STYLE
  DJ CATEGORY

Graphical Interface
- GUI for managing songs
- Filter by BPM or genre
- Export for Suno or DAW

Website Integration
-------------------

This system can later be integrated into the
666SOUNDsDESIGn website framework.

Possible modules:
- song database viewer
- lyric editor
- AI prompt generator
- DJ set builder

Recommended Use
---------------

Works well with:

• Suno AI
• AI music engines
• DAW production workflows
• prompt engineering systems
• DJ vocal sample generation

Creator Note
------------

This system supports large‑scale AI‑assisted
music production archives where hundreds
of song ideas can be structured and reused.