666SOUNDsDESIGn + SongLab Master Workspace Export
=================================================

Purpose
-------
This package consolidates the work produced in the chat into one structured workspace.
It includes source archives, extracted files, recreated missing addons, prompts, and integration notes.

What this workspace contains
----------------------------
1. Original source archives gathered during the chat
2. Extracted project files for review and merge work
3. Recreated missing addons that were discussed but not present as standalone ZIPs
4. Final production prompt for immediate use
5. Integration notes and merge guidance
6. Suggested project structure for the unified system

Core architecture
-----------------
Framework = Engine kernel
HTML website = Host / UI shell
API / Worker = Bridge between UI and model / storage

Protected systems
-----------------
Do NOT modify directly:
- Audio Core
- Sticky Player core logic
- Media Coordinator
- Render Engine
- Background Engine

SongLab must remain an ADDON module.

Security rule
-------------
SongLab access is protected through Worker authentication.
Store the password only as a Worker Secret:

SONGLAB_PASSWORD

Recommended worker routes
-------------------------
POST /songlab/auth
POST /songlab/generate
POST /songlab/save
POST /songlab/load
POST /songlab/project/save
POST /songlab/project/restore
POST /songlab/project/list

Recommended integration order
-----------------------------
1. Review /02_EXTRACTED/Radio_Blueprints
2. Review /02_EXTRACTED/SongLab_Module_v1
3. Review /02_EXTRACTED/SongLab_Framework_v4_8
4. Review /02_EXTRACTED/SongLab_Framework_v6_1
5. Use /02_EXTRACTED/SongLab_Framework_v6_2_Combined as current merge baseline
6. Add Save/Load addon, Generation Guard, and Project Versioning Guard
7. Adapt UI design to the real radio HUD
8. Wire Worker auth and Neocities-based storage
9. Integrate SongLab as a header navigation item called "SongLab"

Recommended current baseline
----------------------------
Use this as the best starting point:
02_EXTRACTED/SongLab_Framework_v6_2_Combined/

Then merge in:
- 02_EXTRACTED/Save_Load_Addon/
- 02_EXTRACTED/Recreated_Generation_Guard_v1/
- 02_EXTRACTED/Project_Versioning_Guard/

Immediate-use prompt
--------------------
See:
03_PROMPTS/FINAL_PRODUCTION_PROMPT_SUNO_S5_DEFAULT.txt

Notes on missing/recreated pieces
---------------------------------
Two discussed addon packages were recreated here from the chat content because
standalone ZIP files were not present in the available workspace:
- Recreated_Feature_Expansion_v6_2
- Recreated_Generation_Guard_v1