PROJECT VERSIONING GUARD INTEGRATION
====================================

This module should run during Save operations.

Pipeline:

User presses SAVE
→ Draft object prepared
→ VERSIONING GUARD creates snapshot
→ Worker storage writes new version file

Recommended storage structure:

/songlab-projects/
    project_001/
        v1.json
        v2.json
        v3.json

Worker API routes:

POST /songlab/project/save
POST /songlab/project/restore
POST /songlab/project/list

Important:
Version files must be protected by Worker authentication.

Integration goal:
Allow safe experimentation without losing previous song drafts.