
# SongLab Output Safety Layer (UPDATED)

The ChatGPT model output must NEVER be used directly.
All generated results must pass through validation before being stored or displayed.

Required modules:

js/songlab/engine/output-validator.js
js/songlab/engine/output-normalizer.js

----------------------------------------------------
TITLE VALIDATION
----------------------------------------------------
max 200 characters

----------------------------------------------------
LYRICS VALIDATION
----------------------------------------------------
max 5000 characters
max 250 lines

----------------------------------------------------
SUNO STYLE PROMPT VALIDATION
----------------------------------------------------
soft limit: 1000 characters
review threshold: 1200 characters
hard safety limit: 1500 characters

Validator should NOT aggressively cut prompts.
It should only:
• remove duplicate genre chains
• remove meta explanations
• prevent broken prompts

----------------------------------------------------
STYLE PROMPT VALIDATION
----------------------------------------------------
soft limit: 1000 characters
review threshold: 1200 characters
hard safety limit: 1500 characters

----------------------------------------------------
STRUCTURE VALIDATION
----------------------------------------------------
Allowed blocks:
Verse
Hook
Bridge
Outro
Intro (optional)

If validation fails:
activate review mode.
