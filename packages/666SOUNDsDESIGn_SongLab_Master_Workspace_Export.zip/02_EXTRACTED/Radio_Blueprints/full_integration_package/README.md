
# 666SOUNDsDESIGn — Full Integration Package

This ZIP contains the architectural documentation and integration instructions
required to extend the 666SOUNDsDESIGn WebRadio system.

IMPORTANT RULE:
The receiving system must build an ADDON only.

Do NOT rebuild the website.
Do NOT restructure the project.
Do NOT replace existing radio systems.

The addon must extend the project by integrating the
SUNO ULTRA LYRIC ENGINE (SongLab).

The design must remain identical to the existing site:
Cyber HUD style
Neon accents
Glass panels
Laser outlines
