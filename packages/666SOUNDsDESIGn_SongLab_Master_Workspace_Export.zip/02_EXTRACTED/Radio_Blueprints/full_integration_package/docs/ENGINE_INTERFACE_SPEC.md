
ENGINE INTERFACE SPEC

Main Engine Function:

generateSong(engineState)

Input example:
{
  mode: "keyword",
  inputText: "dark frequencies cyber galaxy psytrance",
  genre: "PSYTECHNO",
  mood: "DARK"
}

Output:
{
  title: "...",
  lyrics: "...",
  sunoPrompt: "...",
  stylePrompt: "..."
}

Raw input must always be preserved.
