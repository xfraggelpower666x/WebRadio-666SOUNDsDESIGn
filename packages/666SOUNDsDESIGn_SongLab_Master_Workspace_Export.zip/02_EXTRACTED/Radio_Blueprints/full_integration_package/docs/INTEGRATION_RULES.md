
INTEGRATION RULES

- Build ADDON only
- Do not modify radio systems
- No duplicate audio engines
- No duplicate render loops
- API calls must go through Worker/backend
- No OpenAI API keys in browser code
