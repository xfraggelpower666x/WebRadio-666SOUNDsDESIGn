
SONG LAB MODES

1. Manual Lyrics
User writes lyrics freely.

2. Keyword Generator
User enters keywords.
System generates lyrics + prompts.

3. Lyrics Formatter
User pastes raw lyrics.
System structures them into:
Verse
Hook
Bridge
Outro
