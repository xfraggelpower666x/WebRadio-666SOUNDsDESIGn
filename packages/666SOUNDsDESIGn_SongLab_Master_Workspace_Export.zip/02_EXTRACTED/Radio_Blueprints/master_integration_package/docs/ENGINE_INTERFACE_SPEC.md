
ENGINE INTERFACE

generateSong(engineState)

Input:
mode
inputText
genre
mood

Output:
title
lyrics
sunoPrompt
stylePrompt
