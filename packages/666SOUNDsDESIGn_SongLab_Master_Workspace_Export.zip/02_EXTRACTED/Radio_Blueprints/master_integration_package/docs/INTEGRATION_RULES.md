
INTEGRATION RULES

Addon only.
Do not rebuild website.
Do not duplicate audio engines.
All AI calls through Worker/backend.
