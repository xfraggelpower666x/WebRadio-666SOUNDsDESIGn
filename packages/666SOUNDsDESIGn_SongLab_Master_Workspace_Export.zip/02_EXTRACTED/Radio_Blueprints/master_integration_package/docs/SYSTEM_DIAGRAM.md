
SYSTEM DIAGRAM

USER INTERFACE
│
├ Header HUD
├ Hero Intro
├ Sticky Player
├ Media Pages
├ SONG LAB
└ Admin Panel

CORE SYSTEMS
│
├ Global Config Engine
├ State Manager
├ Global Event Bus
├ Media Coordinator
├ Central Audio Core
├ Unified Render Engine
└ Background Engine

Audio Flow

Source
 ↓
Media Coordinator
 ↓
Audio Core
 ↓
Analyser
 ↓
Visualizers
