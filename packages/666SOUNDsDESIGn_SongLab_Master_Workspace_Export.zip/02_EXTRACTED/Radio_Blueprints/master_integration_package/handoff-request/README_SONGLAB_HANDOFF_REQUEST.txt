SONG LAB INTEGRATION — HANDOFF REQUEST PACKAGE
==============================================

Purpose
-------
This package tells the other chat exactly what it needs to return so the SongLab module
can be fully built and then integrated into the existing HTML radio website with minimal
rework.

Current situation
-----------------
We already have:
- SongLab integration architecture blueprint
- module boundaries
- framework concept for SUNO ULTRA LYRIC ENGINE
- addon-only rule set
- worker/backend requirement for API calls

What is still missing
---------------------
The exact visual and technical host website context is still missing.
Without that, the SongLab module can be designed structurally, but not matched precisely
to the existing web radio HUD, hero, sticky player, panel system, and current JS/CSS conventions.

Return package required from the other chat
-------------------------------------------
Please generate ONE ZIP that contains as much of the following as possible.

REQUIRED
--------
1) Current website files
   - index.html
   - all relevant CSS files
   - all relevant JS files
   - any shared layout partials if used
   - any config files relevant to frontend behavior

2) Assets used by the live visual design
   - logo files
   - header / HUD graphics
   - hero images
   - backgrounds / tiles / overlays
   - icons used in nav / player / panels

3) Current project structure
   - folder tree
   - which files are global/shared
   - which files must never be modified directly
   - which files are intended for addon insertion

4) SongLab target placement info
   - where SongLab should appear in navigation
   - where SongLab panel should render in DOM
   - whether SongLab is a full page, modal, tab, drawer, or embedded panel
   - whether mobile layout differs from desktop

5) Existing design rules
   - colors
   - fonts
   - spacing system
   - panel style
   - button style
   - glow / neon behavior
   - responsive behavior
   - z-index / overlay conventions

6) Technical integration constraints
   - existing event bus usage
   - current state manager pattern
   - naming conventions
   - existing fetch/worker helper functions
   - current notification/toast/status system
   - current copy-to-clipboard utility if one exists

STRONGLY RECOMMENDED
--------------------
7) Screenshots
   Include screenshots of:
   - full homepage
   - header/HUD
   - hero area
   - sticky player
   - a normal content panel
   - mobile view if available

8) Notes for immutable areas
   A short text file listing:
   - files that must not be broken
   - CSS selectors that are already critical
   - JS modules that are fragile or tightly coupled
   - any old bugs that must not return

9) Backend / API path info
   - whether a Cloudflare Worker already exists
   - worker filename/path
   - current fetch endpoint names
   - env var expectations
   - whether OpenAI-compatible requests already exist somewhere

10) Exact desired SongLab features for v1
    Please state whether v1 must include:
   - engine selection (S45 / S5)
   - lyrics textarea
   - keyword mode
   - review mode for line shortening approval
   - 3 code box output
   - 4 code box output with structure
   - copy buttons
   - save/load preset
   - dark HUD styling
   - mobile support

Optional but useful
-------------------
11) Existing component references
   If the site already has reusable panels/buttons/inputs, include those files so SongLab
   can match the existing component system instead of inventing a new one.

12) Existing typography references
   If fonts are custom, include font filenames or exact font names already used by the site.

13) Existing animation patterns
   Include any CSS/JS used for:
   - panel open/close
   - glow pulse
   - hover effects
   - sticky transitions
   - intro transitions

Deliverable format requested from the other chat
------------------------------------------------
Please return ONE ZIP containing:
- the files
- screenshots
- a short README answering the questions below
- no unnecessary duplicates if possible

README questions for the other chat to answer
----------------------------------------------
1. Which file controls the main page layout?
2. Which file controls the main HUD/header styling?
3. Which file controls the sticky player?
4. Which file controls content panel styling?
5. Where exactly should SongLab be inserted?
6. Which files are safe to edit?
7. Which files should be treated as read-only?
8. Is there already a worker/backend endpoint for AI requests?
9. Which existing styles/components should SongLab visually inherit?
10. What mobile constraints already exist?

Ideal return ZIP structure
--------------------------
/website-core
  index.html
  css/
  js/
  assets/

/screenshots
  homepage.png
  header.png
  hero.png
  player.png
  panel.png
  mobile.png

/notes
  integration-notes.md
  immutable-areas.md
  file-map.md

/backend
  worker.js
  api-notes.md

/songlab-target
  placement-notes.md
  feature-scope-v1.md

Important integration rule
--------------------------
SongLab must be implemented as an ADDON.
It must not break or rewrite:
- global audio systems
- sticky player logic
- media coordinator
- render/background core
- existing radio navigation behavior

Build objective
---------------
The goal is to produce a package that allows the next stage to build SongLab so it can be
dropped into the radio website with minimal manual restructuring.
