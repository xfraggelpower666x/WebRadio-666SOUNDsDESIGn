Apply these modules to the current SongLab framework v6.1/v6.2 combined package.

1) Add a Genre select to SongLab UI.
2) Before generation:
   - read selected genre
   - if AUTO use inferGenre(inputText)
   - call buildSongStructure({ genre, mode, inputText })
   - inject structure into prompt builder / engine state
3) Project library is a placeholder using localStorage.
   Replace localStorage with worker + Neocities storage when integrating live.