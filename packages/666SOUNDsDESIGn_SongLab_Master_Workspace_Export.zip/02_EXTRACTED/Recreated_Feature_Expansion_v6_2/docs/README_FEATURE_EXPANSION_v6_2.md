SONGLAB FEATURE EXPANSION v6.2
==============================

This recreated package restores the v6.2 addon modules discussed in the chat:
1. Genre Selector
2. Auto Song Structure Builder
3. SongLab Project Library

These modules are addon-only and should be merged into the SongLab framework/UI
without touching protected radio core systems.