export function buildSongStructure({ genre = "TECHNO", mode = "lyrics", inputText = "" } = {}) {
  const base = [
    { key: "INTRO", label: "Intro", target: "0:50-1:10" },
    { key: "BUILD", label: "Build", target: "1:10-1:25" },
    { key: "PRE_DROP", label: "Pre-Drop", target: "0:20-0:35" },
    { key: "DROP", label: "Drop", target: "0:50-1:00" },
    { key: "MID", label: "Mid", target: "1:10-1:30" },
    { key: "OUTRO", label: "Outro", target: "0:45-1:05" }
  ];

  if (genre === "CINEMATIC_INTRO") {
    return [
      { key: "INTRO", label: "Intro", target: "1:00-1:30" },
      { key: "NARRATIVE_BUILD", label: "Narrative Build", target: "1:10-1:40" },
      { key: "SIGNAL_RISE", label: "Signal Rise", target: "0:25-0:40" },
      { key: "DROP", label: "Activation Peak", target: "0:45-0:55" },
      { key: "MID", label: "Transmission Body", target: "1:10-1:30" },
      { key: "OUTRO", label: "Outro", target: "0:40-1:00" }
    ];
  }

  if (genre === "DNB") {
    return [
      { key: "INTRO", label: "Intro", target: "0:35-0:55" },
      { key: "BUILD", label: "Build", target: "0:50-1:10" },
      { key: "PRE_DROP", label: "Pre-Drop", target: "0:15-0:25" },
      { key: "DROP", label: "Drop", target: "0:45-0:55" },
      { key: "MID", label: "Mid", target: "1:00-1:20" },
      { key: "OUTRO", label: "Outro", target: "0:35-0:50" }
    ];
  }

  return base;
}