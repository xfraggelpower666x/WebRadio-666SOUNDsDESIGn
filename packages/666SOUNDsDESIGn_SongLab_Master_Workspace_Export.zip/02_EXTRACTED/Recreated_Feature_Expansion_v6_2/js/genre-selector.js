export const SONG_GENRES = [
  { id: "TECHNO", label: "Techno", bpmRange: "128-140", energy: "driving" },
  { id: "HARD_TECHNO", label: "Hard Techno", bpmRange: "145-155", energy: "aggressive" },
  { id: "PSYTRANCE", label: "Psytrance", bpmRange: "138-148", energy: "hypnotic" },
  { id: "DNB", label: "Drum & Bass", bpmRange: "170-178", energy: "fast" },
  { id: "DARK_ELECTRO", label: "Dark Electro", bpmRange: "120-135", energy: "dark" },
  { id: "CINEMATIC_INTRO", label: "Cinematic Intro", bpmRange: "free", energy: "narrative" }
];

export function inferGenre(inputText = "") {
  const text = inputText.toLowerCase();

  if (/hard techno|warehouse|pound|steel|no escape/.test(text)) return "HARD_TECHNO";
  if (/psy|psytrance|ritual|fractal|dimension|cosmic/.test(text)) return "PSYTRANCE";
  if (/dnb|drum.?and.?bass|break|rush|bassline|velocity/.test(text)) return "DNB";
  if (/cinematic|transmission|intro|galaxy|narrator|system online/.test(text)) return "CINEMATIC_INTRO";
  if (/electro|dark synth|dark electro/.test(text)) return "DARK_ELECTRO";

  return "TECHNO";
}