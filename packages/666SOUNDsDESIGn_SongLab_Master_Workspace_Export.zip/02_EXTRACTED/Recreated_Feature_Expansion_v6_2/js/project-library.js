const STORAGE_KEY = "songlab_project_library";

export function loadProjectLibrary() {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
  } catch {
    return [];
  }
}

export function saveProjectEntry(entry) {
  const library = loadProjectLibrary();
  const id = entry.id || `project_${Date.now()}`;
  const now = new Date().toISOString();

  const normalized = {
    id,
    title: entry.title || "Untitled Project",
    engine: entry.engine || "S5",
    mode: entry.mode || "keywords",
    genre: entry.genre || "TECHNO",
    inputText: entry.inputText || "",
    lyrics: entry.lyrics || "",
    stylePrompt: entry.stylePrompt || "",
    sunoPrompt: entry.sunoPrompt || "",
    updatedAt: now,
    createdAt: entry.createdAt || now
  };

  const next = library.filter(item => item.id !== id);
  next.unshift(normalized);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
  return normalized;
}

export function deleteProjectEntry(id) {
  const next = loadProjectLibrary().filter(item => item.id !== id);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
  return next;
}