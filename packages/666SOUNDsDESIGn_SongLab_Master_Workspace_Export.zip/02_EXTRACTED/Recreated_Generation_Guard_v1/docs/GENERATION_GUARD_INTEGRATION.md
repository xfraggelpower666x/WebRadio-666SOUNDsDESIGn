This module should be appended to the SongLab framework after the main lyric engine processing stage.

Recommended pipeline:

INPUT
→ Mode Detection
→ Genre Detection
→ Structure Builder
→ Lyric Generation
→ Suno Formatting
→ GENERATION GUARD SYSTEM
→ OUTPUT

If REVIEW_MODE is triggered, the UI should show:
Original line
Proposed change
Reason