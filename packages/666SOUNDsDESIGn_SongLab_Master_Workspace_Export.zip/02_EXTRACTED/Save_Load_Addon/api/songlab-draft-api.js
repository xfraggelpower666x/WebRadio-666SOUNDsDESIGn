
export async function saveDraft(draft) {

  const res = await fetch("/songlab/save", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ draft })
  })

  return await res.json()
}

export async function loadDraft(draftId) {

  const res = await fetch("/songlab/load", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ draftId })
  })

  return await res.json()
}
