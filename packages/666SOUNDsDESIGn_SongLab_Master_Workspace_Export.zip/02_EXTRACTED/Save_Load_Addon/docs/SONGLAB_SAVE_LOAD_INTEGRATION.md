
SONGLAB SAVE/LOAD INTEGRATION NOTES
===================================

Purpose
-------
SongLab now includes Save and Load capabilities for song drafts.
The storage backend is expected to use the Neocities API that already exists
inside the main radio project.

IMPORTANT ARCHITECTURE RULE
---------------------------
SongLab is an ADDON MODULE.

The following systems must NEVER be modified:

- Audio Core
- Sticky Player logic
- Media Coordinator
- Render Engine
- Background Engine

SongLab communicates only through the worker and the Neocities API layer.

Expected Worker Routes
----------------------

POST /songlab/auth
POST /songlab/generate
POST /songlab/save
POST /songlab/load

Authentication
--------------
All routes must require authentication through the worker.

Password must be stored as a Worker Secret:

SONGLAB_PASSWORD


Draft Object Structure
----------------------

A saved draft should use the following structure:

{
  "id": "draft_001",
  "createdAt": "timestamp",
  "updatedAt": "timestamp",
  "mode": "lyrics | keywords",
  "engine": "S45 | S5",
  "title": "song title",
  "inputText": "keywords or idea text",
  "lyrics": "generated lyrics",
  "stylePrompt": "style prompt",
  "sunoPrompt": "suno prompt",
  "structure": "optional structure"
}

Storage Strategy
----------------

The Neocities API should store draft files in a dedicated folder:

/songlab-drafts/

Example files:

songlab-drafts/draft_001.json
songlab-drafts/draft_002.json

Save Logic
----------

POST /songlab/save

Body:

{
  draftObject
}

Worker should forward the data to the Neocities API and write the JSON file.

Load Logic
----------

POST /songlab/load

Body:

{
  draftId
}

Worker returns the stored JSON file.

Frontend Behaviour
------------------

SongLab UI should include:

- Generate button
- Save button
- Load button
- Draft list selector (optional)

When LOAD is pressed:
the returned draft object should repopulate all fields in the UI.

Security
--------

Draft files must never be publicly listed or indexed.
Access must only happen through the worker.

The worker must validate authentication before allowing save/load.
