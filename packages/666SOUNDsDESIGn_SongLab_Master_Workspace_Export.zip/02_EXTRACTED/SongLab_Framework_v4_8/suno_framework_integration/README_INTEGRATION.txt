SUNO FRAMEWORK HTML INTEGRATION PACKAGE

Purpose
This package gives your other chat or developer a ready-to-insert source package
for integrating the current framework state into an HTML website.

Files
- SUNO_ULTRALYRIC_ENGINE_CURRENT_APPEND_PATCH_v4_8.txt
  Current append-only prompt master. Append this after your existing v4.4 base.

- suno-framework-config.js
  Exports the current patch text and framework defaults.

- suno-framework-widget.html
  Drop-in UI block for preset selection, intro length, beat mode, and prompt assembly.

- suno-framework-api-example.js
  Example server-side API bridge for OpenAI/ChatGPT style completion calls.
  Do not expose your real API key in browser code.

- integration-notes.txt
  Practical integration notes for the other chat/developer.

Suggested integration flow
1. Keep your canonical v4.4 base prompt in one file.
2. Append the v4.8 patch from this package.
3. Let the UI choose:
   - preset
   - intro class
   - beat chant mode
   - lyrics
4. Build the final prompt string server-side.
5. Send the assembled prompt to your model endpoint.

Security note
Do not place your real API key in client-side HTML or JS.
Use a backend route or worker.
