// Example backend route for assembling and sending the final prompt.
// Keep your API key on the server only.

import express from 'express';
import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';
import { buildFinalPrompt } from './suno-framework-config.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
app.use(express.json({ limit: '1mb' }));

app.post('/api/suno-framework/build', async (req, res) => {
  try {
    const {
      basePromptPath,
      preset,
      introClass,
      beatMode = true,
      difficultWords = '',
      lyrics = ''
    } = req.body || {};

    let basePrompt = '';
    if (basePromptPath) {
      const resolved = path.resolve(__dirname, basePromptPath);
      basePrompt = await fs.readFile(resolved, 'utf-8');
    }

    const finalPrompt = buildFinalPrompt({
      basePrompt,
      preset,
      introClass,
      beatMode,
      difficultWords,
      lyrics
    });

    res.json({ ok: true, finalPrompt });
  } catch (error) {
    res.status(500).json({ ok: false, error: error.message });
  }
});

app.listen(3000, () => {
  console.log('Suno framework integration server running on http://localhost:3000');
});
