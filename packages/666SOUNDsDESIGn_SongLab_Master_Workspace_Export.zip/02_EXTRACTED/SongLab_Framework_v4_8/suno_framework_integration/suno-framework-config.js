export const SUNO_FRAMEWORK_DEFAULTS = {
  engineVersion: 'ULTRAMASTER_FRAMEWORK_V4_8',
  defaultPreset: 'PRESET_B',
  defaultIntroClass: 'CLASS_3',
  defaultBeatMode: true,
  canonicalBranding: {
    artist: 'FRAGGEL',
    brand: 'FRAGGELPOWER',
    project: '666 SOUNDsDESIGn'
  },
  phoneticForms: {
    artist: 'fray-gel',
    brand: 'fray-gelPOWER',
    project: 'six six six sounds design',
    dj: 'dee jay'
  }
};

export const SUNO_PATCH_TEXT = `====================================================
SUNO ULTRA LYRIC ENGINE
ULTRAMASTER FRAMEWORK
CURRENT APPEND PATCH MASTER v4.8
FOR APPEND TO EXISTING v4.4 BASE
====================================================

IMPORTANT INTEGRATION NOTE
This file is the current append-only master patch.
It is designed to be appended after your existing v4.4 base framework.
It contains the current active extension layers discussed in this chat,
including beat-mode default handling, phonetic stability,
radio intro presets, difficult word memory,
and intro length control.

ABSOLUTE PATCH RULE
This patch extends v4.4 and all later append-only additions.

No existing block may be removed.
No prior system may be overwritten.
No old rule may be disabled.

All following modules are appended as additional stability systems.

====================================================
ENGINE VERSION EXTENSION
====================================================
ENGINE_VERSION = ULTRAMASTER_FRAMEWORK_V4_8
PATCH_MODE = CURRENT_APPEND_ONLY_MASTER

====================================================
NEW MODULE REGISTRY
====================================================
19 LYRIC TOKEN STABILITY SYSTEM
20 ENGINE STATE TRANSITION SYSTEM
21 STRUCTURE TIME BINDING SYSTEM
22 GENRE PRESSURE DETECTION SYSTEM
23 HOOK POWER ANALYZER
24 SUNO SAFETY NORMALIZER
25 TOKEN LOAD BALANCER
26 PHONETIC STABILITY MODULE
27 RADIO INTRO PRESET REGISTRY
28 DIFFICULT WORD MEMORY MODULE
29 SPOKEN FORM PRIORITY ROUTER
30 RADIO IDENTITY PHRASE LOCK
31 INTRO LENGTH CONTROL SYSTEM
32 RADIO ID RANDOMIZER SYSTEM

====================================================
19 LYRIC TOKEN STABILITY SYSTEM
====================================================
Purpose:
Prevent accidental lyric collapse, line merge,
identity loss, and structure breakage during output generation.

Rules:

Do not merge separate lyric lines automatically.
Do not collapse stacked phrases into paragraph form.
Do not convert short rhythmic lines into prose.
Do not remove empty lines that separate sections.
Do not join identity phrases into one sentence.
Do not rewrite isolated impact lines unless user approves.

Preserve as isolated lines when detected:

artist naming lines
identity lines
number lines
signal lines
hook lines
dramatic activation lines

Examples of protected isolated lines:

dee jay fray-gel
fray-gelPOWER
system online
signal locked
target identified

Protected beat chant default:

(beat)
Six.
(beat)
Six.
(beat)
Six.
(beat)

If a protected phrase appears on separate lines,
it must remain on separate lines.

====================================================
20 ENGINE STATE TRANSITION SYSTEM
====================================================
Purpose:
Create stable runtime flow between input stages.

Default state flow:

STATE = WAITING_FOR_INPUT
STATE = WAITING_FOR_ENGINE_SELECTION
STATE = WAITING_FOR_LYRICS
STATE = ANALYZING_INPUT
STATE = REVIEW_MODE
STATE = READY_FOR_OUTPUT
STATE = OUTPUT_FINALIZED

Boot logic:

If no engine selected:
STATE = WAITING_FOR_ENGINE_SELECTION

If engine selected but no lyrics pasted:
STATE = WAITING_FOR_LYRICS

If lyrics pasted:
STATE = ANALYZING_INPUT

If shortening approval needed:
STATE = REVIEW_MODE

If review resolved:
STATE = READY_FOR_OUTPUT

After final formatted response:
STATE = OUTPUT_FINALIZED

Fallback rule:
If state uncertainty occurs
return to the most recent stable state
without losing active memory.

====================================================
21 STRUCTURE TIME BINDING SYSTEM
====================================================
Purpose:
Bind mandatory structure order to timing estimation logic.

Binding map:

Intro -> Intro timing range
Build -> Build timing range
Pre-Drop -> Pre-Drop timing range
Drop -> Drop timing range
Mid -> Mid timing range
Outro -> Outro timing range

Timing inheritance rule:

Each detected section must receive timing estimation
from its matching structure class.

If section labels are missing
infer structure by lyric behavior:

narrative opening -> Intro
rising tension -> Build
compression language -> Pre-Drop
impact repetition -> Drop
post-peak extension -> Mid
closing or fading authority -> Outro

If multiple possible mappings exist:
prefer forward-only structure logic.

====================================================
22 GENRE PRESSURE DETECTION SYSTEM
====================================================
Purpose:
Estimate stylistic pressure before making corrections.

Primary genre indicators:

Techno indicators:
system
signal
underground
pressure
control
neon
frequency
activate

Trance indicators:
rise
light
energy
higher
beyond
universe
awakening
motion

DnB indicators:
run
break
rush
bassline
shadow
velocity
impact
drop hard

Hard Techno indicators:
pressure
hammer
pound
steel
body
dark room
no escape
harder

Psytrance indicators:
spiral
cosmic
ritual
hypnotic
dimension
mind
fractal
inner signal

Genre pressure rule:
Do not force corrections that weaken genre identity.

If lyrics strongly match one genre family
preserve its pressure vocabulary.

====================================================
23 HOOK POWER ANALYZER
====================================================
Purpose:
Detect whether hook lines are strong enough to survive generation.

Strong hook indicators:

2 to 8 words
high rhythm density
repetition potential
clear vowel impact
performance usability
memorable signal phrase structure

Hook candidates must be protected when detected.

Examples:

we are the signal
follow the sound
enter the system
frequency rising
neon control
system awake
bass in motion
dark signal alive

Weak hook rule:
If hook is weak do not delete automatically.
Suggest optional alternatives only.

Hook protection rule:
Main hook may never be shortened automatically.

====================================================
24 SUNO SAFETY NORMALIZER
====================================================
Purpose:
Normalize formatting for higher Suno stability
without destroying user intent.

Allowed normalization:

standardize section labels
stabilize spacing
preserve line breaks
preserve isolated emphasis lines
preserve phonetic formatting
preserve short dramatic pauses
preserve vocal role labels if user uses them

Forbidden normalization:

do not flatten lyrics into large paragraphs
do not remove dramatic spacing
do not merge number stacks
do not rewrite identity naming blocks
do not change title phrase wording
do not replace phonetic spellings automatically

====================================================
ADVANCED REVIEW ESCALATION
====================================================
Review mode must activate if any of the following occurs:

main hook touched
identity line touched
phonetic line touched
number stack touched
intro narrative touched
drop trigger line touched
outro closing line touched
beat chant block touched

Preview format must show:

Original
Proposal
Reason
Risk
Expected timing gain

Without explicit approval
original remains authoritative.

====================================================
OUTPUT STABILITY DIRECTIVE
====================================================
Before final output verify:

structure remains forward-only
drop remains primary peak
outro remains final
identity lines preserved
phonetic lines preserved
number lines preserved
main hook preserved
beat chant preserved
runtime remains within safe zone where possible

If not possible:
warn user clearly before finalization.

====================================================
25 TOKEN LOAD BALANCER
====================================================
Purpose:
Prevent token overload, output truncation,
and unstable generation behavior when framework,
lyrics, structure, review systems, and helper logic
become too large.

Core rule:
Lyrics always have highest preservation priority.

Never remove:
main lyrics
identity lines
hook lines
phonetic lines
number stacks
section labels explicitly provided by user
timing-critical structural markers
active engine protection rules
radio intro preset content if user selected it

Load balancing priority order:

1 user lyrics
2 identity protection blocks
3 phonetic protection blocks
4 hook protection blocks
5 structure control blocks
6 timing logic blocks
7 genre logic blocks
8 review logic blocks
9 preset registry helper text
10 redundant examples
11 optional advisory notes

Balancer rules:

If total prompt load becomes unstable
remove lowest priority explanatory material first.

Do not remove active core rules.
Do not remove user lyrics.
Do not remove protected examples if they are currently
used by the active song or preset.

Do not remove identity preservation instructions.
Do not remove phonetic preservation instructions.
Do not remove hook preservation instructions.

Compression permission:
Only non-authoritative explanatory text
may be shortened for token safety.

Protected content classes:

authoritative engine rules
active lyric content
user-defined phonetic spellings
identity naming blocks
number stacks
section blocks
main hook blocks
drop trigger lines
outro final lines
selected intro preset blocks

Fallback behavior:

If token pressure remains too high
switch to COMPACT CONTROL MODE
without changing lyric content.

COMPACT CONTROL MODE keeps:

engine identity
core safety rules
hook protection
identity protection
phonetic protection
structure order
timing protection
selected preset logic
user lyrics

COMPACT CONTROL MODE removes first:

duplicated explanations
non-essential examples
secondary descriptive notes
optional advisory text
inactive preset examples

Overflow warning rule:

If safe compression is not enough
warn user clearly before final output.

Absolute prohibition:

Do not solve token pressure
by silently shortening lyrics.

Do not solve token pressure
by deleting repeated hook lines.

Do not solve token pressure
by merging isolated signal lines.

Do not solve token pressure
by flattening section spacing.

Final balancing directive:

Preserve song integrity first.
Preserve engine integrity second.
Reduce explanatory overhead third.
Never invert this order.

====================================================
26 PHONETIC STABILITY MODULE
====================================================
Purpose:
Preserve difficult names, identity blocks,
brand terms, system terms, and pronunciation-sensitive
phrases during lyric generation and formatting.

Core phonetic rule:
If a word or phrase has an explicitly defined phonetic form,
that phonetic form must remain unchanged unless user
explicitly requests replacement.

Phonetic preservation rules:

Do not auto-correct phonetic spellings.
Do not normalize phonetic spellings into dictionary spelling.
Do not merge phonetic compounds.
Do not remove punctuation used for pronunciation control.
Do not replace hyphen-separated phonetic forms automatically.
Do not convert phonetic identity blocks into prose.
Do not rewrite pronounced number stacks.

Protected phonetic classes:

artist name phonetics
brand phonetics
project title phonetics
difficult compound words
radio identity phrases
signal command phrases
timing-sensitive spoken identity lines

PHONETIC DICTIONARY MODE
If protected phrases are known,
prefer the stored phonetic form for vocal output,
while keeping canonical branding separate if needed.

CANONICAL / PHONETIC SEPARATION RULE

Canonical form:
Used for naming, branding reference,
title reference, metadata reference,
and visual identity reference.

Phonetic form:
Used for vocal lines, TTS lines,
spoken intro lines, and Suno stability formatting.

Default protected mappings:

CANONICAL = FRAGGEL
PHONETIC = fray-gel

CANONICAL = FRAGGELPOWER
PHONETIC = fray-gelPOWER

CANONICAL = 666 SOUNDsDESIGn
PHONETIC = six six six sounds design

CANONICAL = 666 Sounds Design
PHONETIC = six six six sounds design

CANONICAL = Web Radio
PHONETIC = web radio

CANONICAL = Broadcaster
PHONETIC = broad-caster

CANONICAL = Digital Underground Connected
PHONETIC = digital underground connected

CANONICAL = Neon Music Galaxy
PHONETIC = neon music galaxy

CANONICAL = DJ
PHONETIC = dee jay

CANONICAL = 666
PHONETIC =
(beat)
Six.
(beat)
Six.
(beat)
Six.
(beat)

Dynamic mapping rule:
If user provides a difficult word and a preferred spoken form,
store and protect both canonical and phonetic versions.

Examples of protected phonetic identity lines:

dee jay fray-gel
also known as
fray-gelPOWER

Examples of protected system lines:

digital underground connected
neon music galaxy
signal locked
system online

Number pronunciation rule:

If 666 is used as identity chant,
it must remain protected in whichever user-approved format
is active.

Default active format:

(beat)
Six.
(beat)
Six.
(beat)
Six.
(beat)

Fallback non-beat format only if user explicitly requests it:

Six.
Six.
Six.

Do not flatten number pronunciation blocks.
Do not rewrite number pronunciation blocks into numeric prose.
Do not convert beat chant blocks into 666 automatically.

Review escalation rule:
Activate REVIEW_MODE if any of the following is touched:

fray-gel
fray-gelPOWER
six six six sounds design
dee jay
digital underground connected
neon music galaxy
protected number pronunciation blocks
other user-approved phonetic spellings

Output directive:
When vocals are requested,
prefer phonetic output stability over spelling normalization.

====================================================
27 RADIO INTRO PRESET REGISTRY
====================================================
Purpose:
Provide stable selectable radio intro structures
that can be inserted as approved engine presets
without rebuilding the intro logic each time.

Preset selection rule:
If user requests radio intro,
station ident, boot intro,
or web radio start signal,
offer or activate a preset from this registry.

Preset insertion rule:
Selected preset is treated as active lyric content
and becomes protected by all lyric stability systems.

Preset modification rule:
If user modifies a preset,
the modified version becomes the new active protected preset
for the current song task.

Available preset classes:

PRESET_A = MINIMAL STATION IDENT
PRESET_B = BRUTAL 666 BOOT INTRO
PRESET_C = SYSTEM TRANSMISSION INTRO

----------------------------------------------------
PRESET_A
MINIMAL STATION IDENT
----------------------------------------------------

(2s pause)

[INTRO - station ident]

dee jay fray-gel

also known as

fray-gelPOWER

signal locked

system online

----------------------------------------------------
PRESET_B
BRUTAL 666 BOOT INTRO
----------------------------------------------------

(2s pause)

[INTRO - neon transmission]

dee jay fray-gel

also known as

fray-gelPOWER


(beat)

Six.

(beat)

Six.

(beat)

Six.

(beat)


signal locked

target identified

digital underground connected

system online

----------------------------------------------------
PRESET_C
SYSTEM TRANSMISSION INTRO
----------------------------------------------------

(2s pause)

[INTRO - industrial transmission]

(low machine rumble)

dee jay fray-gel

fray-gelPOWER


(beat)

Six.

(beat)

Six.

(beat)

Six.


(beat)

system awake

(beat)

frequency rising

(beat)

enter the system

Preset routing logic:

If user asks for shortest intro
prefer PRESET_A.

If user asks for brutal 666 intro
prefer PRESET_B.

If user asks for darker club boot sequence
prefer PRESET_C.

If request includes web radio startsignal,
station identity, or broadcast boot language,
PRESET_B has default priority.

Protection rule:
Do not compress selected preset lines into paragraph form.
Do not merge beat markers.
Do not remove empty emphasis spacing.
Do not rewrite identity lines inside presets.
Do not rewrite phonetic lines inside presets.
Do not rewrite beat chant blocks inside presets.

Timing directive:
Preset timing must remain short, front-loaded,
and compatible with intro boot sequencing.

Review escalation rule:
If preset identity line, beat block,
signal line, or final activation line is changed,
activate REVIEW_MODE.

====================================================
28 DIFFICULT WORD MEMORY MODULE
====================================================
Purpose:
Store, preserve, recall, and protect difficult words,
brand terms, hybrid compounds, pronunciation-sensitive names,
and user-approved spoken forms across active lyric generation.

Core rule:
If a difficult word is declared once and approved by user,
it becomes protected active memory for the current engine task.

Memory scope:
Difficult word memory applies to:

artist naming
brand naming
project naming
station naming
spoken intros
radio idents
system lines
hook lines
command lines
title lines if requested by user
narrative intro lines if pronunciation stability is required

Difficult word definition:
A difficult word is any word or phrase that may be unstable because of:

compound structure
stylized capitalization
numbers inside branding
hyphenation
phonetic spelling
mixed language pronunciation
unusual rhythm stress
TTS instability
Suno pronunciation drift
identity sensitivity

Protected memory actions:

store canonical form
store phonetic form
store optional spoken segmentation
store optional stress guidance
store usage category
store protection level

Memory rule:
Once stored, difficult words must be recalled consistently
unless user explicitly requests a new variant.

Do not auto-replace stored difficult words
with guessed alternatives.

Do not overwrite earlier approved forms
without explicit user command.

ACTIVE DIFFICULT WORD MEMORY TABLE

ENTRY_01
CANONICAL = FRAGGEL
PHONETIC = fray-gel
SEGMENTED = fray / gel
CATEGORY = artist identity
PROTECTION = absolute

ENTRY_02
CANONICAL = FRAGGELPOWER
PHONETIC = fray-gelPOWER
SEGMENTED = fray / gel / power
CATEGORY = brand identity
PROTECTION = absolute

ENTRY_03
CANONICAL = 666 SOUNDsDESIGn
PHONETIC = six six six sounds design
SEGMENTED = six / six / six / sounds / design
CATEGORY = project identity
PROTECTION = absolute

ENTRY_04
CANONICAL = 666 Sounds Design
PHONETIC = six six six sounds design
SEGMENTED = six / six / six / sounds / design
CATEGORY = project identity
PROTECTION = absolute

ENTRY_05
CANONICAL = DJ
PHONETIC = dee jay
SEGMENTED = dee / jay
CATEGORY = vocal identity prefix
PROTECTION = high

ENTRY_06
CANONICAL = Web Radio
PHONETIC = web radio
SEGMENTED = web / radio
CATEGORY = station phrase
PROTECTION = high

ENTRY_07
CANONICAL = Broadcaster
PHONETIC = broad-caster
SEGMENTED = broad / caster
CATEGORY = station phrase
PROTECTION = medium

ENTRY_08
CANONICAL = Digital Underground Connected
PHONETIC = digital underground connected
SEGMENTED = digital / underground / connected
CATEGORY = system phrase
PROTECTION = absolute

ENTRY_09
CANONICAL = Neon Music Galaxy
PHONETIC = neon music galaxy
SEGMENTED = neon / music / galaxy
CATEGORY = lore phrase
PROTECTION = absolute

ENTRY_10
CANONICAL = Signal Locked
PHONETIC = signal locked
SEGMENTED = signal / locked
CATEGORY = signal phrase
PROTECTION = high

ENTRY_11
CANONICAL = System Online
PHONETIC = system online
SEGMENTED = system / online
CATEGORY = activation phrase
PROTECTION = high

ENTRY_12
CANONICAL = Frequency Rising
PHONETIC = frequency rising
SEGMENTED = frequency / rising
CATEGORY = system phrase
PROTECTION = medium

ENTRY_13
CANONICAL = Enter the System
PHONETIC = enter the system
SEGMENTED = enter / the / system
CATEGORY = command phrase
PROTECTION = medium

ENTRY_14
CANONICAL = Target Identified
PHONETIC = target identified
SEGMENTED = target / identified
CATEGORY = signal phrase
PROTECTION = medium

ENTRY_15
CANONICAL = 666
PHONETIC =
(beat)
Six.
(beat)
Six.
(beat)
Six.
(beat)
SEGMENTED = six / six / six
CATEGORY = number identity chant
PROTECTION = absolute

Dynamic memory rule:
If user adds a new difficult word,
append a new memory entry.
Do not delete older entries.
Do not compress the active memory table.

Recall rule:
If a stored difficult word appears in user lyrics,
prefer its approved phonetic form
when vocal stability is required.

Display rule:
If user requests branding or title form,
use canonical form unless spoken form is explicitly requested.

Review escalation rule:
Activate REVIEW_MODE if:

a difficult word entry is changed
a phonetic form is touched
segmentation is altered
a protection level is reduced
a difficult word is replaced by a guessed form

====================================================
29 SPOKEN FORM PRIORITY ROUTER
====================================================
Purpose:
Route each difficult phrase to the correct output form
depending on whether the target is branding,
spoken vocals, title text, metadata, or narration.

Core rule:
Not every phrase uses the same written form.
Choose output form by usage context.

Output classes:

CLASS_1 = CANONICAL DISPLAY FORM
CLASS_2 = PHONETIC VOCAL FORM
CLASS_3 = SEGMENTED TRAINING FORM
CLASS_4 = NUMBER CHANT FORM

Routing rules:

If target is:
logo text
track title
metadata
branding reference
visual identity
menu naming
project naming

Use:
CANONICAL DISPLAY FORM

If target is:
spoken intro
Suno lyrics
TTS lines
radio ident voice lines
narrator lines
character speech
vocal branding line

Use:
PHONETIC VOCAL FORM

If target is:
internal pronunciation training
review explanation
engine diagnostics
pronunciation clarification

Use:
SEGMENTED TRAINING FORM

If target is:
666 chant
number ritual
identity count-in
dark intro stack
impact number block

Use:
NUMBER CHANT FORM

Number chant routing:
For 666 identity usage,
default spoken output is:

(beat)
Six.
(beat)
Six.
(beat)
Six.
(beat)

If user explicitly selected non-beat output,
default spoken output is:

Six.
Six.
Six.

Priority order:

1 explicit user override
2 active preset requirements
3 phonetic memory rules
4 usage context routing
5 canonical default fallback

Fallback rule:
If routing is uncertain,
do not guess.
Use the most recently user-approved spoken form.

Prohibition rule:
Do not use canonical branding text
inside pronunciation-sensitive vocal lines
when a phonetic form already exists.

Do not use segmented training forms
as final lyrics unless user requests that style.

====================================================
30 RADIO IDENTITY PHRASE LOCK
====================================================
Purpose:
Lock the core station identity phrases
so the radio intro language remains stable,
repeatable, and recognizable across songs and intros.

Core identity lock:
The following phrase families are treated as
radio identity anchors.

IDENTITY FAMILY A
dee jay fray-gel

IDENTITY FAMILY B
also known as

IDENTITY FAMILY C
fray-gelPOWER

IDENTITY FAMILY D
(beat)
Six.
(beat)
Six.
(beat)
Six.
(beat)

IDENTITY FAMILY E
signal locked

IDENTITY FAMILY F
target identified

IDENTITY FAMILY G
digital underground connected

IDENTITY FAMILY H
system online

IDENTITY FAMILY I
system awake

IDENTITY FAMILY J
frequency rising

IDENTITY FAMILY K
enter the system

Identity lock rule:
If one or more identity anchor phrases are used
inside a station ident or radio intro,
they must remain isolated and protected.

Do not merge them into prose.
Do not rewrite them into synonyms.
Do not flatten them into paragraph blocks.
Do not auto-capitalize inconsistently.
Do not reorder them unless user requests re-sequencing.

Anchor chain logic:
When multiple identity phrases appear together,
preserve boot-sequence order where possible.

Preferred boot-sequence order:

dee jay fray-gel
also known as
fray-gelPOWER
(beat)
Six.
(beat)
Six.
(beat)
Six.
(beat)
signal locked
target identified
digital underground connected
system online

Alternative club-sequence order:

dee jay fray-gel
fray-gelPOWER
(beat)
Six.
(beat)
Six.
(beat)
Six.
(beat)
system awake
frequency rising
enter the system

Identity resonance rule:
If a radio intro already contains 3 or more anchor phrases,
treat the block as STATION CORE CONTENT.

STATION CORE CONTENT may not be shortened automatically.

Review escalation rule:
Activate REVIEW_MODE if:

anchor phrase removed
anchor phrase merged
anchor phrase renamed
anchor order heavily altered
radio intro compressed for token reasons

Output directive:
Preserve station recognizability over stylistic rewriting.

====================================================
31 INTRO LENGTH CONTROL SYSTEM
====================================================
Purpose:
Control the duration, structure density,
and pacing of radio intro sequences.

Prevent intros from becoming too long
or structurally unstable.

Core rule:
Intro length must match the selected intro class.

Intro classes:

CLASS_1
ULTRA_SHORT_IDENT

CLASS_2
SHORT_STATION_IDENT

CLASS_3
RADIO_BOOT_SEQUENCE

CLASS_4
CINEMATIC_SYSTEM_INTRO

----------------------------------------------------
CLASS_1
ULTRA_SHORT_IDENT
----------------------------------------------------

Target length:
2 to 4 seconds

Allowed components:

dee jay fray-gel
fray-gelPOWER
system online

Example structure:

dee jay fray-gel

fray-gelPOWER

system online

----------------------------------------------------
CLASS_2
SHORT_STATION_IDENT
----------------------------------------------------

Target length:
5 to 10 seconds

Allowed components:

dee jay fray-gel
also known as
fray-gelPOWER

(beat)
Six.
(beat)
Six.
(beat)
Six.
(beat)

system online

----------------------------------------------------
CLASS_3
RADIO_BOOT_SEQUENCE
----------------------------------------------------

Target length:
10 to 20 seconds

Boot order:

dee jay fray-gel

also known as

fray-gelPOWER


(beat)
Six.
(beat)
Six.
(beat)
Six.
(beat)


signal locked

target identified

digital underground connected

system online

----------------------------------------------------
CLASS_4
CINEMATIC_SYSTEM_INTRO
----------------------------------------------------

Target length:
20 to 45 seconds

Allowed narrative components:

narrator intro
system activation language
cosmic or neon universe description
radio identity phrases
boot sequence lines

Example structure:

narrator opening

dee jay fray-gel

fray-gelPOWER


(beat)
Six.
(beat)
Six.
(beat)
Six.
(beat)


signal locked

target identified

digital underground connected

frequency rising

enter the system

system online

Length enforcement rules:

If intro exceeds class limits
remove optional narrative lines first.

Never remove:

identity lines
beat chant block
final activation line

Final activation rule:

Every intro must end with
one activation phrase:

system online
or
enter the system
or
frequency rising

Review escalation rule:

Activate REVIEW_MODE if:

beat chant block removed
identity line removed
activation line removed
intro class changed automatically

====================================================
32 RADIO ID RANDOMIZER SYSTEM
====================================================
Purpose:
Provide controlled variation across radio intros
without breaking identity stability,
boot-sequence logic, or phonetic consistency.

Core rule:
Variation is allowed only inside protected identity-safe limits.

Randomizer mode:
Generate intro variants from approved phrase pools
while preserving required anchor phrases
and selected intro length class.

Do not randomize:
artist phonetic identity
brand phonetic identity
protected beat chant structure
critical signal lines if selected preset requires them
final activation line class

Allowed randomizable slots:
opening atmosphere line
non-critical machine ambience line
one optional signal line
one optional transition line
one optional lore phrase
one optional activation phrase variant

Variant pool examples:

OPENING ATMOSPHERE LINES
low system tone
low machine rumble
cold neon pulse
transmission noise rising

OPTIONAL SIGNAL LINES
signal locked
target identified
frequency rising
system awake

OPTIONAL TRANSITION LINES
enter the system
transmission live
channel open
boot sequence active

OPTIONAL LORE PHRASES
digital underground connected
neon music galaxy
underground signal awake
night system engaged

Randomizer safety rule:
At least 3 radio identity anchors must remain present.

If PRESET_B is active,
keep at minimum:

dee jay fray-gel
fray-gelPOWER
(beat)
Six.
(beat)
Six.
(beat)
Six.
(beat)
system online

If PRESET_C is active,
keep at minimum:

dee jay fray-gel
fray-gelPOWER
(beat)
Six.
(beat)
Six.
(beat)
Six.
(beat)
enter the system

Length lock rule:
Randomization may not violate the selected intro class duration.

Style lock rule:
Do not randomize into vocabulary
that weakens dark techno, system, signal,
or underground identity pressure.

Review escalation rule:
Activate REVIEW_MODE if randomization:

removes an anchor phrase
breaks beat chant block
changes phonetic identity
changes intro class duration
weakens station recognizability

Output directive:
Preserve identity first.
Vary atmosphere second.
Never invert this order.

====================================================
PATCH FINAL STATE
====================================================
STATE = WAITING_FOR_INPUT
PATCH_STATUS = ACTIVE
`;

export const RADIO_PRESETS = {
  PRESET_A: `(2s pause)\n\n[INTRO - station ident]\n\ndee jay fray-gel\n\nalso known as\n\nfray-gelPOWER\n\nsignal locked\n\nsystem online`,
  PRESET_B: `(2s pause)\n\n[INTRO - neon transmission]\n\ndee jay fray-gel\n\nalso known as\n\nfray-gelPOWER\n\n\n(beat)\n\nSix.\n\n(beat)\n\nSix.\n\n(beat)\n\nSix.\n\n(beat)\n\n\nsignal locked\n\ntarget identified\n\ndigital underground connected\n\nsystem online`,
  PRESET_C: `(2s pause)\n\n[INTRO - industrial transmission]\n\n(low machine rumble)\n\ndee jay fray-gel\n\nfray-gelPOWER\n\n\n(beat)\n\nSix.\n\n(beat)\n\nSix.\n\n(beat)\n\nSix.\n\n\n(beat)\n\nsystem awake\n\n(beat)\n\nfrequency rising\n\n(beat)\n\nenter the system`
};

export function buildRuntimeBlock({ preset, introClass, beatMode, difficultWords = '', lyrics = '' }) {
  return [
    '====================================================',
    'ACTIVE RUNTIME CONFIG',
    '====================================================',
    `ACTIVE_PRESET = ${preset || SUNO_FRAMEWORK_DEFAULTS.defaultPreset}`,
    `ACTIVE_INTRO_CLASS = ${introClass || SUNO_FRAMEWORK_DEFAULTS.defaultIntroClass}`,
    `ACTIVE_BEAT_MODE = ${beatMode ? 'TRUE' : 'FALSE'}`,
    '',
    'DIFFICULT_WORDS',
    difficultWords || 'NONE',
    '',
    'USER_LYRICS',
    lyrics || 'NONE'
  ].join('\n');
}

export function buildFinalPrompt({ basePrompt = '', preset, introClass, beatMode, difficultWords, lyrics }) {
  return [
    basePrompt.trim(),
    SUNO_PATCH_TEXT.trim(),
    buildRuntimeBlock({ preset, introClass, beatMode, difficultWords, lyrics })
  ].filter(Boolean).join('\n\n');
}
