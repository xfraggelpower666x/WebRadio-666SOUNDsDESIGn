SONGLAB + SUNO ENGINE v6.1 CURRENT INTEGRATION GUIDE
===================================================

Purpose
-------
This package contains the current framework text file and the current HTML integration stub
for the 666SOUNDsDESIGn SongLab system.

What this package is for
------------------------
This package is meant for the other chat to integrate into the radio project.

It contains:
1) the current routed framework text file
2) an updated HTML SongLab stub
3) a save/load system explanation
4) integration instructions

Authoritative source
--------------------
Use:
SUNO_ULTRA_LYRIC_ENGINE_ULTRAMASTER_v6_1_ROUTED_MASTER.txt

as the current master framework source.

If project-side logic duplicates rules that are already contained in this file:
- remove the duplicate if it conflicts
- keep the v6.1 framework authoritative for engine logic

If project-side functionality is new and not conflicting:
- integrate it as an add-on system

Core radio protection
---------------------
SongLab must remain an ADDON module.

Do not directly modify:
- Audio Core
- Media Coordinator
- Sticky Player core logic
- Render Engine
- Background Engine

Required UI behavior
--------------------
At startup the SongLab flow must ask in this order:

1) Which Suno version?
   - S45
   - S5

2) What do you want to build?
   - INTRO
   - SONG

If SONG:
3) ask:
   - LYRICS
   - IDEA

If INTRO:
3) ask:
   - A
   - B
   - C
   - D

Final output rule
-----------------
The system must output exactly 3 codeboxes in this order:

1) TITLE ONLY
2) STYLE PROMPT
3) LYRIC PROMPT

The lyric prompt box must contain:
- atmosphere instructions
- timing instructions
- song structure
- section labels
- embedded structural timing if needed

Do not add a fourth codebox.

After the 3 codeboxes, always ask:

Do you want to change anything?

Offer:
- MOD
- FULL MOD
- KEEP

MOD / FULL MOD requirement
--------------------------
The system must continue to support short command edits after generation.

Examples:
- MOD BPM 150
- MOD GENRE Hard Techno
- MOD LANG German
- MOD MOOD Dark
- FULL MOD darker rewrite
- FULL MOD switch to psytrance

Save / Load system explanation
------------------------------
The included HTML file still uses localStorage as a temporary fallback.

This must be replaced project-side with Worker-authenticated storage.

Recommended routes:

POST /songlab/auth
POST /songlab/save
GET  /songlab/load?id=...
GET  /songlab/projects/list
POST /songlab/projects/delete

Recommended architecture:

Browser
  ↓
Worker auth check
  ↓
Neocities API or site storage layer

The frontend must not contain:
- password secrets
- API keys
- worker secrets

Suggested saved object shape
----------------------------
{
  "id": "project_001",
  "title": "...",
  "engine_version": "ULTRAMASTER_v6_1",
  "primary_mode": "SONG|INTRO",
  "submode": "LYRICS|IDEA|A|B|C|D",
  "genre": "...",
  "bpm": "...",
  "lang": "...",
  "mood": "...",
  "style_note": "...",
  "input": "...",
  "title_output": "...",
  "style_prompt": "...",
  "lyrics_prompt": "...",
  "project_notes": "...",
  "number_chant_mode": "ACTIVE"
}

What still needs project-side integration
-----------------------------------------
1) Style the HTML to match the real 666SOUNDsDESIGn design
2) Wire SongLab into the top radio header navigation
3) Replace localStorage with Worker + Neocities API save/load
4) Keep authentication only in the Worker
5) Optionally connect ChatGPT/OpenAI endpoint for automatic generation
6) Respect v6.1 routing and output order exactly

Files in this package
---------------------
- SUNO_ULTRA_LYRIC_ENGINE_ULTRAMASTER_v6_1_ROUTED_MASTER.txt
- songlab_radio_integration_v6_1.html
- README_FOR_OTHER_CHAT_v6_1.txt
- SAVE_LOAD_SYSTEM_v6_1.md
