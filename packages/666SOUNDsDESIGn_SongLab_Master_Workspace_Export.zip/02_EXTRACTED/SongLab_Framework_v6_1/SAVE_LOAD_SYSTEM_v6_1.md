SAVE / LOAD SYSTEM v6.1
=======================

Current fallback
----------------
The HTML stub saves drafts locally with localStorage only.
This is for testing and temporary fallback.

Target production storage
-------------------------
Replace localStorage with:

Worker route layer
  ↓
Neocities API or project storage layer

Required worker behavior
------------------------
1) authenticate request
2) deny public lyric access
3) save project draft
4) load project draft
5) list projects
6) delete project

Suggested routes
----------------
POST /songlab/auth
POST /songlab/save
GET  /songlab/load?id=...
GET  /songlab/projects/list
POST /songlab/projects/delete

Security rule
-------------
Password handling must remain in Worker secrets only.
Do not store secrets in:
- HTML
- frontend JS
- CSS
- exported public config

Suggested payload for save
--------------------------
{
  "id": "project_001",
  "title": "Generated Song Draft",
  "engine_version": "ULTRAMASTER_v6_1",
  "primary_mode": "SONG",
  "submode": "IDEA",
  "genre": "Hard Techno",
  "bpm": "150",
  "lang": "German",
  "mood": "Dark",
  "style_note": "More aggressive",
  "input": "dark neon underground signal ...",
  "title_output": "Generated Song Draft",
  "style_prompt": "...",
  "lyrics_prompt": "...",
  "project_notes": "",
  "number_chant_mode": "ACTIVE"
}

Frontend rule
-------------
The frontend may:
- collect data
- send authenticated save/load requests
- show returned drafts

The frontend must not:
- validate password locally
- expose secrets
- bypass worker auth

Design note
-----------
The included HTML file is integration-oriented, not final-styled.
The other chat must adapt the design to the real radio HUD and layout.
