SONGLAB FRAMEWORK v6.2 COMBINED HANDOFF
======================================

What this package is
--------------------
This is the combined SongLab handoff package that merges:

- authoritative SongLab framework v6.1 routed master
- SongLab HTML integration stub
- save/load integration notes
- v6.2 feature expansion modules

Authoritative rule
------------------
The framework text file remains the engine authority:

framework/SUNO_ULTRA_LYRIC_ENGINE_ULTRAMASTER_v6_1_ROUTED_MASTER.txt

The v6.2 JS files are addon feature modules and must be wired into the current SongLab UI/manager logic.

New v6.2 features included
--------------------------
1. Genre Selector
2. Auto Song Structure Builder
3. Project Library

Current status
--------------
This package is functionally prepared but still requires project-side integration:

- adapt UI design to the real 666SOUNDsDESIGn radio HUD
- wire SongLab into the header menu as "SongLab"
- connect worker-auth routes
- replace localStorage project library with worker + Neocities storage if desired

Protected systems
-----------------
Do NOT modify:
- Audio Core
- Media Coordinator
- Sticky Player core logic
- Render Engine
- Background Engine

Worker/auth rule
----------------
Password must remain only in Worker secrets as:
SONGLAB_PASSWORD

Suggested protected routes
--------------------------
POST /songlab/auth
POST /songlab/generate
POST /songlab/save
GET  /songlab/load?id=...
GET  /songlab/projects/list
POST /songlab/projects/delete

Recommended next integration step
---------------------------------
1. Add Genre select to the HTML/UI
2. Before generation:
   - read selected genre
   - if AUTO use inferGenre(inputText)
   - build structure with buildSongStructure(...)
   - inject structure into prompt builder
3. Use project-library.js as temporary library logic
4. Swap project-library.js storage to protected worker storage if needed

Files to hand to the integration chat
-------------------------------------
Everything in this package can be forwarded as a single zip.
The integration chat should use:
- framework/...
- ui/...
- js/...
- docs/...
- data/...