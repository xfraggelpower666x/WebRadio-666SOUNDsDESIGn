INTEGRATION NOTES FOR OTHER CHAT
================================

Apply these modules to the current SongLab framework v6.1.

1) Genre Selector UI
Add a select element such as:

<select id="songlabGenre">
  <option value="AUTO">Auto Detect</option>
  <option value="TECHNO">Techno</option>
  <option value="HARD_TECHNO">Hard Techno</option>
  <option value="PSYTRANCE">Psytrance</option>
  <option value="DNB">Drum & Bass</option>
  <option value="DARK_ELECTRO">Dark Electro</option>
  <option value="CINEMATIC_INTRO">Cinematic Intro</option>
</select>

2) Manager wiring
Before generation:
- read selected genre
- if AUTO use inferGenre(inputText)
- call buildSongStructure({ genre, mode, inputText })
- inject structure into prompt builder / engine state

3) Project Library wiring
Add buttons:
- Save Project
- Load Project
- Delete Project

Current library module uses localStorage as a placeholder.
If the main integration already has worker auth + Neocities storage,
replace localStorage with protected remote storage.

4) Safety
These modules are addon-only.
Do not rewrite protected radio core systems.