SONGLAB FEATURE EXPANSION v6.2
==============================

This package adds the three feature blocks requested after the current v6.1 framework:

1. Genre Selector
2. Auto Song Structure Builder
3. SongLab Project Library

Purpose
-------
These files are designed as addon modules and must be merged into the existing SongLab system
without modifying protected radio core systems.

Included files
--------------
js/genre-selector.js
  - static genre registry
  - light auto-detection helper

js/auto-structure-builder.js
  - structure profiles by genre
  - timing presets for output planning

js/project-library.js
  - local project library example
  - can later be swapped to worker + Neocities storage

Integration intent
------------------
Genre Selector:
- expose a select field in SongLab UI
- default to user selection
- fall back to inferGenre() when auto mode is enabled

Auto Structure Builder:
- build structure blocks before generation
- pass structure into prompt builder
- allow optional output box for structure

Project Library:
- supports multiple song drafts/projects
- current version uses localStorage as a safe placeholder
- integration chat may replace this with authenticated worker storage

Important
---------
This expansion does NOT touch:
- Audio Core
- Sticky Player logic
- Media Coordinator
- Render Engine
- Background Engine