# SongLab Module v1

Drop-in addon module for the 666SOUNDsDESIGn website.

This package includes:
- SongLab UI panel markup
- scoped CSS
- frontend manager/UI/engine bridge
- Cloudflare Worker backend example
- framework reference files
- installation notes

The module is intentionally isolated from the existing radio core.
