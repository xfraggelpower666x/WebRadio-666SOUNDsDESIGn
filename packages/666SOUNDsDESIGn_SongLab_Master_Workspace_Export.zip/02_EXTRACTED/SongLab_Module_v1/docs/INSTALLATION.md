# SongLab Module v1 Installation

## Files to include in the website

Load these files in this order:

1. `css/songlab/songlab.css`
2. `js/songlab/config/engine-config.js`
3. `js/songlab/engine/prompt-builder.js`
4. `js/songlab/engine/ultralyrics-engine.js`
5. `js/songlab/song-copy-panel.js`
6. `js/songlab/songlab-ui.js`
7. `js/songlab/songlab-manager.js`

## HTML mount point

Insert this where SongLab should render:

```html
<div id="songlab-root"></div>
```

Then inject the panel markup from `html/songlab-panel.html` into that container.

## Minimal bootstrap

```html
<script>
  fetch('/path/to/html/songlab-panel.html')
    .then((res) => res.text())
    .then((markup) => {
      document.getElementById('songlab-root').innerHTML = markup;
      window.SongLabManager.initSongLab();
    });
</script>
```

## Backend

Deploy `worker/openai-worker.js` as the backend endpoint.
Set:

- `OPENAI_API_KEY`
- `OPENAI_MODEL` (optional)

Default frontend endpoint:

`/api/songlab/generate`
