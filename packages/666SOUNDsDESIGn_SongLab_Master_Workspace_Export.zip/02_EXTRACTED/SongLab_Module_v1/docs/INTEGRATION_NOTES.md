# SongLab v1 Integration Notes

- This module is addon-only.
- It does not touch the existing audio engine, sticky player, or media coordinator.
- All AI requests are routed through the worker backend.
- Styling is intentionally self-contained and namespaced with `songlab-`.
- Current visual style is a generic dark neon HUD because the live site assets were not provided.
- Once the real website files are available, only CSS and mount placement should need refinement.

## Included v1 features

- Engine selection: S45 / S5
- Manual Lyrics mode
- Keyword Generator mode
- Lyrics Formatter mode
- Review mode UI for major shortening
- 3 output boxes by default
- optional structure box
- copy buttons
- save/load preset in localStorage
- mobile responsive layout
