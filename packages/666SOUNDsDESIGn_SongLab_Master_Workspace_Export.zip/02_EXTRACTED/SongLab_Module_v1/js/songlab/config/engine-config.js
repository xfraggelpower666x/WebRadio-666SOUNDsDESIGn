(function (global) {
  const SongLabConfig = {
    apiEndpoint: '/api/songlab/generate',
    storageKey: 'songlab_v1_preset',
    defaultEngine: 'S5',
    defaultMode: 'manual',
    defaultGenre: 'AUTO',
    defaultMood: 'DARK',
    frameworkVersion: 'ULTRAMASTER_FRAMEWORK_V4_5',
    enableReviewMode: true,
  };

  global.SongLabConfig = SongLabConfig;
})(window);
