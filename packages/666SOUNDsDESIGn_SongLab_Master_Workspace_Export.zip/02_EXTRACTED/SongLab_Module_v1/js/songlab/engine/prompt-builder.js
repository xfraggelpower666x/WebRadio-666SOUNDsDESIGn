(function (global) {
  function escapeSection(value) {
    return String(value || '').trim();
  }

  function buildSongLabRequest(payload) {
    const reviewInstructions = payload.reviewMode
      ? 'If major lyric shortening is needed, return reviewRequired=true and include proposals instead of finalizing silently.'
      : 'You may finalize directly without review mode.';

    const structureInstructions = payload.showStructure
      ? 'Return structure in the response.'
      : 'structure may be empty.';

    const modeDescriptionMap = {
      manual: 'User pasted lyrics that must be preserved unless review mode is triggered.',
      keyword: 'User provided keywords and needs a complete Suno-ready concept.',
      formatter: 'User provided rough lyrics/raw text and needs formatting into a Suno-ready structure.'
    };

    return {
      engine: payload.engine,
      mode: payload.mode,
      requestType: 'songlab_generate',
      frameworkVersion: (global.SongLabConfig && global.SongLabConfig.frameworkVersion) || 'ULTRAMASTER_FRAMEWORK_V4_5',
      systemInstructions: [
        'Execute the SongLab engine logic only.',
        'Respect protected phonetic forms and isolated impact lines.',
        'Return valid JSON only.',
        reviewInstructions,
        structureInstructions,
      ].join(' '),
      userContext: {
        genre: escapeSection(payload.genre),
        mood: escapeSection(payload.mood),
        titleHint: escapeSection(payload.titleHint),
        inputText: String(payload.inputText || ''),
        modeDescription: modeDescriptionMap[payload.mode] || modeDescriptionMap.manual,
        showStructure: Boolean(payload.showStructure),
        reviewMode: Boolean(payload.reviewMode),
      },
    };
  }

  global.SongLabPromptBuilder = {
    buildSongLabRequest,
  };
})(window);
