(function (global) {
  async function generateSong(engineState) {
    const endpoint = (global.SongLabConfig && global.SongLabConfig.apiEndpoint) || '/api/songlab/generate';
    const requestPayload = global.SongLabPromptBuilder.buildSongLabRequest(engineState);

    const response = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(requestPayload),
    });

    if (!response.ok) {
      const text = await response.text();
      throw new Error(text || `SongLab request failed with status ${response.status}`);
    }

    const data = await response.json();
    return normalizeResponse(data, engineState);
  }

  function normalizeResponse(data, engineState) {
    return {
      title: data.title || '',
      lyrics: data.lyrics || '',
      sunoPrompt: data.sunoPrompt || '',
      stylePrompt: data.stylePrompt || '',
      structure: data.structure || '',
      reviewRequired: Boolean(data.reviewRequired),
      reviewItems: Array.isArray(data.reviewItems) ? data.reviewItems : [],
      meta: {
        engine: engineState.engine,
        mode: engineState.mode,
      },
    };
  }

  global.SongLabEngine = {
    generateSong,
  };
})(window);
