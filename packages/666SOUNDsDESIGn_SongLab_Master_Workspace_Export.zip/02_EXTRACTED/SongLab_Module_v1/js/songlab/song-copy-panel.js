(function (global) {
  async function copyTextFromElement(targetId) {
    const node = document.getElementById(targetId);
    if (!node) return false;
    const text = node.textContent || '';
    if (!text.trim()) return false;

    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch (error) {
      const textarea = document.createElement('textarea');
      textarea.value = text;
      textarea.setAttribute('readonly', 'readonly');
      textarea.style.position = 'absolute';
      textarea.style.left = '-9999px';
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand('copy');
      document.body.removeChild(textarea);
      return true;
    }
  }

  function wireCopyButtons(updateStatus) {
    document.querySelectorAll('.songlab-copy-btn').forEach((button) => {
      button.addEventListener('click', async () => {
        const ok = await copyTextFromElement(button.dataset.copyTarget);
        updateStatus(ok ? 'Copied' : 'Nothing to copy', ok ? 'success' : 'warning');
      });
    });
  }

  global.SongLabCopyPanel = { wireCopyButtons };
})(window);
