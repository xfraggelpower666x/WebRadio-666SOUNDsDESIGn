(function (global) {
  const state = {
    lastRequest: null,
    reviewPendingRequest: null,
    reviewResponse: null,
  };

  async function handleGenerate() {
    try {
      const engineState = global.SongLabUI.readEngineState();
      if (!engineState.inputText.trim()) {
        global.SongLabUI.updateStatus('Paste lyrics or keywords first', 'warning');
        return;
      }

      state.lastRequest = engineState;
      global.SongLabUI.updateStatus('Generating...', 'busy');
      const result = await global.SongLabEngine.generateSong(engineState);

      if (result.reviewRequired && result.reviewItems.length) {
        state.reviewPendingRequest = engineState;
        state.reviewResponse = result;
        document.getElementById('songlab-review').hidden = false;
        global.SongLabUI.renderReviewItems(result.reviewItems);
        global.SongLabUI.updateStatus('Review required', 'warning');
        return;
      }

      document.getElementById('songlab-review').hidden = true;
      global.SongLabUI.writeOutputs(result);
      global.SongLabUI.updateStatus('Generation complete', 'success');
    } catch (error) {
      console.error(error);
      global.SongLabUI.updateStatus(error.message || 'Generation failed', 'error');
    }
  }

  function handleApproveReview() {
    if (!state.reviewResponse) return;
    const approvedLyrics = state.reviewResponse.approvedLyrics || state.reviewResponse.lyrics || '';
    const approvedResult = {
      ...state.reviewResponse,
      lyrics: approvedLyrics,
      reviewRequired: false,
      reviewItems: [],
    };
    document.getElementById('songlab-review').hidden = true;
    global.SongLabUI.writeOutputs(approvedResult);
    global.SongLabUI.updateStatus('Review approved', 'success');
  }

  function handleKeepOriginal() {
    if (!state.reviewPendingRequest) return;
    const originalResult = {
      title: state.reviewResponse.title || state.reviewPendingRequest.titleHint || '',
      lyrics: state.reviewPendingRequest.inputText,
      sunoPrompt: state.reviewResponse.sunoPrompt || '',
      stylePrompt: state.reviewResponse.stylePrompt || '',
      structure: state.reviewResponse.structure || '',
    };
    document.getElementById('songlab-review').hidden = true;
    global.SongLabUI.writeOutputs(originalResult);
    global.SongLabUI.updateStatus('Original kept', 'success');
  }

  function initSongLab() {
    global.SongLabUI.attachCoreEvents({
      handleGenerate,
      handleApproveReview,
      handleKeepOriginal,
    });
    global.SongLabUI.updateStatus('Ready', 'success');
  }

  global.SongLabManager = {
    initSongLab,
    handleGenerate,
  };
})(window);
