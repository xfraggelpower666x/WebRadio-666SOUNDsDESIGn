(function (global) {
  function $(id) {
    return document.getElementById(id);
  }

  function readEngineState() {
    return {
      engine: $('songlab-engine').value,
      mode: $('songlab-mode').value,
      genre: $('songlab-genre').value,
      mood: $('songlab-mood').value,
      titleHint: $('songlab-title-hint').value.trim(),
      inputText: $('songlab-input').value,
      showStructure: $('songlab-show-structure').checked,
      reviewMode: $('songlab-review-mode').checked,
    };
  }

  function writeOutputs(result) {
    $('songlab-output-style').textContent = result.stylePrompt || result.sunoPrompt || '';
    $('songlab-output-title').textContent = result.title || '';
    $('songlab-output-lyrics').textContent = result.lyrics || '';
    $('songlab-output-structure').textContent = result.structure || '';
    $('songlab-structure-card').hidden = !result.structure;
  }

  function updateStatus(text, tone) {
    const node = $('songlab-status');
    node.textContent = text;
    node.dataset.tone = tone || 'default';
  }

  function clearForm() {
    $('songlab-title-hint').value = '';
    $('songlab-input').value = '';
    $('songlab-output-style').textContent = 'Waiting for generation...';
    $('songlab-output-title').textContent = '';
    $('songlab-output-lyrics').textContent = '';
    $('songlab-output-structure').textContent = '';
    $('songlab-structure-card').hidden = true;
    $('songlab-review').hidden = true;
    $('songlab-review-list').innerHTML = '';
    updateStatus('Idle');
  }

  function savePreset() {
    const key = global.SongLabConfig.storageKey;
    localStorage.setItem(key, JSON.stringify(readEngineState()));
    updateStatus('Preset saved', 'success');
  }

  function loadPreset() {
    const key = global.SongLabConfig.storageKey;
    const raw = localStorage.getItem(key);
    if (!raw) {
      updateStatus('No preset found', 'warning');
      return;
    }
    const preset = JSON.parse(raw);
    $('songlab-engine').value = preset.engine || global.SongLabConfig.defaultEngine;
    $('songlab-mode').value = preset.mode || global.SongLabConfig.defaultMode;
    $('songlab-genre').value = preset.genre || global.SongLabConfig.defaultGenre;
    $('songlab-mood').value = preset.mood || global.SongLabConfig.defaultMood;
    $('songlab-title-hint').value = preset.titleHint || '';
    $('songlab-input').value = preset.inputText || '';
    $('songlab-show-structure').checked = Boolean(preset.showStructure);
    $('songlab-review-mode').checked = preset.reviewMode !== false;
    updateStatus('Preset loaded', 'success');
  }

  function renderReviewItems(items) {
    const list = $('songlab-review-list');
    list.innerHTML = '';

    items.forEach((item, index) => {
      const wrapper = document.createElement('article');
      wrapper.className = 'songlab-review-item';
      wrapper.innerHTML = `
        <strong>Change ${index + 1}</strong>
        <div><span class="songlab-review-meta">Original</span><pre class="songlab-output">${escapeHtml(item.original || '')}</pre></div>
        <div><span class="songlab-review-meta">Proposal</span><pre class="songlab-output">${escapeHtml(item.proposal || '')}</pre></div>
        <div class="songlab-review-meta">Reason: ${escapeHtml(item.reason || 'Not specified')}</div>
        <div class="songlab-review-meta">Impact: ${escapeHtml(item.impact || 'Not specified')}</div>
      `;
      list.appendChild(wrapper);
    });
  }

  function escapeHtml(value) {
    return String(value)
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&#39;');
  }

  function attachCoreEvents(controller) {
    $('songlab-clear').addEventListener('click', clearForm);
    $('songlab-save').addEventListener('click', savePreset);
    $('songlab-load').addEventListener('click', loadPreset);
    $('songlab-generate').addEventListener('click', controller.handleGenerate);
    $('songlab-approve-review').addEventListener('click', controller.handleApproveReview);
    $('songlab-keep-original').addEventListener('click', controller.handleKeepOriginal);
    if (global.SongLabCopyPanel) {
      global.SongLabCopyPanel.wireCopyButtons(updateStatus);
    }
  }

  global.SongLabUI = {
    readEngineState,
    writeOutputs,
    updateStatus,
    clearForm,
    renderReviewItems,
    attachCoreEvents,
  };
})(window);
