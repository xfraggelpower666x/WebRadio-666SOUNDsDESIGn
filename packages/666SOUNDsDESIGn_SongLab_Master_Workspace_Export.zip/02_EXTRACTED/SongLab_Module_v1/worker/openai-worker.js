export default {
  async fetch(request, env) {
    if (request.method === 'OPTIONS') {
      return new Response(null, { status: 204, headers: corsHeaders() });
    }

    const url = new URL(request.url);
    if (url.pathname !== '/api/songlab/generate') {
      return json({ error: 'Not found' }, 404);
    }

    if (request.method !== 'POST') {
      return json({ error: 'Method not allowed' }, 405);
    }

    try {
      const body = await request.json();
      const model = env.OPENAI_MODEL || 'gpt-5';
      const system = buildSystemPrompt(body);
      const user = buildUserPrompt(body);

      const apiResponse = await fetch('https://api.openai.com/v1/responses', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${env.OPENAI_API_KEY}`,
        },
        body: JSON.stringify({
          model,
          input: [
            { role: 'system', content: [{ type: 'input_text', text: system }] },
            { role: 'user', content: [{ type: 'input_text', text: user }] },
          ],
          text: { format: { type: 'json_object' } },
        }),
      });

      if (!apiResponse.ok) {
        const errorText = await apiResponse.text();
        return json({ error: errorText || 'OpenAI request failed' }, 500);
      }

      const apiJson = await apiResponse.json();
      const contentText = extractOutputText(apiJson);
      const parsed = safeJsonParse(contentText);
      return json(parsed, 200);
    } catch (error) {
      return json({ error: error.message || 'Unhandled worker error' }, 500);
    }
  },
};

function buildSystemPrompt(body) {
  return [
    'You are the SUNO ULTRA LYRIC ENGINE running inside SongLab.',
    body.systemInstructions || '',
    'Return JSON with these keys:',
    'title, lyrics, sunoPrompt, stylePrompt, structure, reviewRequired, reviewItems, approvedLyrics.',
    'reviewItems must be an array of objects: { original, proposal, reason, impact }.',
    'Never wrap the JSON in markdown fences.',
  ].join(' ');
}

function buildUserPrompt(body) {
  return JSON.stringify(body.userContext || {}, null, 2);
}

function extractOutputText(apiJson) {
  if (apiJson.output_text) return apiJson.output_text;
  const output = apiJson.output || [];
  for (const item of output) {
    const content = item.content || [];
    for (const block of content) {
      if (block.type === 'output_text' && block.text) return block.text;
    }
  }
  throw new Error('No output text returned by model');
}

function safeJsonParse(text) {
  try {
    return JSON.parse(text);
  } catch (error) {
    return {
      title: '',
      lyrics: text,
      sunoPrompt: '',
      stylePrompt: '',
      structure: '',
      reviewRequired: false,
      reviewItems: [],
      approvedLyrics: '',
    };
  }
}

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
      ...corsHeaders(),
    },
  });
}

function corsHeaders() {
  return {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
  };
}
