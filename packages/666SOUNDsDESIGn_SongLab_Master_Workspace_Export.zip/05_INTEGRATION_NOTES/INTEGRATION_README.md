INTEGRATION README
==================

Target placement
----------------
SongLab should appear as its own menu item in the top header of the radio website.

High-level layers
-----------------
1. UI layer
   - songlab-panel.html
   - songlab-ui.js
   - songlab.css

2. Engine layer
   - framework text files
   - lyric generation logic
   - genre selector
   - structure builder
   - guards

3. Orchestration layer
   - manager
   - prompt builder
   - state handling

4. API/Worker layer
   - auth
   - generate
   - save/load
   - project versioning

5. Output layer
   - style prompt
   - title
   - lyrics
   - optional structure/review preview

Design adaptation reminder
--------------------------
The module logic is prepared, but the visual design still needs to be adapted to the actual
666SOUNDsDESIGn radio HUD / header / hero / panel system by the integration chat or developer.

Storage reminder
----------------
Drafts and project versions should be stored through the protected Worker + Neocities flow.
Do not expose drafts as public static files.