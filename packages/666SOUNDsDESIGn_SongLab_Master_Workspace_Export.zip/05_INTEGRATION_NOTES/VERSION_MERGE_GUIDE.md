VERSION MERGE GUIDE
===================

Goal
----
Merge the available versions into one practical integration baseline without breaking the radio core.

Best baseline
-------------
Start from:
02_EXTRACTED/SongLab_Framework_v6_2_Combined/

Merge order
-----------
1. Keep framework authority from:
   framework/SUNO_ULTRA_LYRIC_ENGINE_ULTRAMASTER_v6_1_ROUTED_MASTER.txt

2. Keep the integrated SongLab UI stub from:
   ui/songlab_radio_integration_v6_1.html

3. Keep the v6.2 addon JS modules:
   js/genre-selector.js
   js/auto-structure-builder.js
   js/project-library.js

4. Add Save/Load wiring from:
   02_EXTRACTED/Save_Load_Addon/api/songlab-draft-api.js
   02_EXTRACTED/Save_Load_Addon/docs/SONGLAB_SAVE_LOAD_INTEGRATION.md

5. Add Generation Guard:
   02_EXTRACTED/Recreated_Generation_Guard_v1/framework/GENERATION_GUARD_SYSTEM_v1.txt

6. Add Project Versioning Guard:
   02_EXTRACTED/Project_Versioning_Guard/framework/PROJECT_VERSIONING_GUARD_SYSTEM_v1.txt

7. Use v4.8 package as reference for older framework integration details:
   02_EXTRACTED/SongLab_Framework_v4_8/

Merge policy
------------
- Add-only
- No destructive overwrite of core framework rules
- No direct edits to protected radio core systems
- UI adaptation should stay separate from framework logic
- Worker/API logic should stay separate from DOM logic