# Merge-Checkliste

## Vor dem Merge
- [ ] Datei gesichert
- [ ] Original unverändert archiviert
- [ ] Dateityp erkannt
- [ ] Rolle erkannt
- [ ] Output-Modus erkannt
- [ ] Direktkommandos erkannt
- [ ] Sprachsystem erkannt

## Während des Merge
- [ ] Als Source Block eingebettet
- [ ] Nicht-destruktiv behandelt
- [ ] Konflikte dokumentiert
- [ ] Alte Regeln nicht gelöscht
- [ ] Legacy-Ausgabe erhalten
- [ ] Wrapper-/Prioritätslogik ergänzt

## Nach dem Merge
- [ ] STATUS weiterhin nutzbar
- [ ] MOD weiterhin nutzbar
- [ ] FULL MOD weiterhin nutzbar
- [ ] SHOW STRUCTURE weiterhin nutzbar
- [ ] 3-Box- und 4-Box-Kompatibilität geprüft
- [ ] Direktparameter bleiben erhalten
- [ ] Sprachzustand bleibt erhalten
- [ ] Lyrics-/Titel-Memory nicht verloren
