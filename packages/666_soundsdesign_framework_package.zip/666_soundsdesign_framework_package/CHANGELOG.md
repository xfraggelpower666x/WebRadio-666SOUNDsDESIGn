# Changelog

## Package state
- current base prompt: v4
- includes quick control system
- includes format detection
- includes atmosphere injection
- includes title copy fix
- includes anti-loop logic
- includes song continuity logic
- includes restart risk reduction
- includes 3-minute context stabilizer
- includes hook intensity controller

## Archived prompt snapshots
Older versions are included in `archive/` for rollback, comparison, and merge reference.
