# 666 SOUNDsDESIGN — SUNO ULTRA LYRIC ENGINE PRO
## Framework Package

Copyright © 666 SoundsDesign

This package contains the current consolidated framework prompt, archived prompt snapshots, and documentation for integrating the framework into another chat, system prompt, or prompt stack.

## Package contents

- `prompts/666_suno_ultra_engine_v4.txt` — current working master prompt
- `prompts/integration_boot_prompt.txt` — short boot helper for loading the framework into another chat
- `docs/INTEGRATION_GUIDE.md` — how to use the framework in another environment
- `docs/VERSION_MERGE_STRATEGY.md` — how to merge multiple versions cleanly
- `docs/TEST_WORKFLOW.md` — practical tests after integration or merge
- `docs/IMPLEMENTATION_NOTES.md` — operator notes and structure logic
- `archive/` — older prompt snapshots for rollback or comparison
- `examples/example_usage.md` — quick usage examples
- `CHANGELOG.md` — package summary

## Recommended base version

Use `prompts/666_suno_ultra_engine_v4.txt` as the main master prompt.

## Core integration rule

Keep the framework in one master prompt and preserve the documented hierarchy.
Do not split it into multiple manually started prompts unless the host system absolutely requires that.

## Merge principle

When merging multiple versions, use v4 as base and reintroduce older features module by module only when they add missing functionality.
Do not blindly append old prompt text to the end.

## Practical workflow

1. Load the master prompt.
2. Paste lyrics.
3. Accept auto-analysis or override with short controls.
4. Use the produced style prompt, title, and final lyrics.
5. Request structure display only when needed.

## Important

The title box rule is part of the framework:
the title code box must contain only the raw title text, with no extra label inside the box.
