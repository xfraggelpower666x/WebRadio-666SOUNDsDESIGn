# Implementation Notes

## Main design choice
This framework is intentionally kept as one master prompt with internal modular hierarchy.
It is not meant to require multiple manually started prompts.

## Why hierarchy matters
Without strict order, these modules can interfere:
- language conversion
- pronunciation mapping
- hook selection
- flow shaping
- structure continuity
- title detection

## Current workflow defaults
- simple output mode
- title box contains only the raw title
- quick controls are compact
- formatted lyrics are preserved
- atmosphere is injected if missing
- structure is hidden unless requested

## Versioning advice
If you create new variations, archive them clearly, for example:
- v4-base
- v4.1-title-fix
- v4.2-loop-fix
- v4.3-format-detection
