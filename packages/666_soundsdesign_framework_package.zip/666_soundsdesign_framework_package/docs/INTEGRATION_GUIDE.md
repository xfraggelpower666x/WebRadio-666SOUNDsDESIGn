# Integration Guide

## Fast integration into another chat

1. Paste `prompts/integration_boot_prompt.txt`
2. Paste the full master prompt from `prompts/666_suno_ultra_engine_v4.txt`
3. Start with one short lyric test
4. Validate:
   - style prompt limit
   - title-only title box
   - preserved structure for formatted lyrics
   - hidden structure output by default

## Integration into an app or workflow

Recommended layers:

### Layer 1 — framework prompt
Contains:
- safety
- hierarchy
- detection logic
- formatting logic
- output rules

### Layer 2 — runtime user input
Contains:
- lyrics
- optional quick commands like `G4`, `V2`, `M3`, `F5`
- optional `SHOW STRUCTURE`

### Layer 3 — operator validation
Check:
- title box contains raw title only
- style prompt stays under limit
- formatted lyrics are preserved
- outro continuity is stable

## What should remain untouched
- output lock
- style prompt hard limit
- title output rule
- anti-loop logic
- continuity logic
- structure tag priority
- user structure lock
- pronunciation mapping order
