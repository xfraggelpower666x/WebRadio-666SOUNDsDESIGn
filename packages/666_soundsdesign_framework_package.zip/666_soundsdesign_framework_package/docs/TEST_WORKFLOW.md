# Test Workflow

## Test 1 — Raw lyrics
Paste plain lyrics with no tags.

Expected:
- framework builds structure
- injects atmosphere
- generates title
- outputs simple mode by default

## Test 2 — Half-formatted lyrics
Paste lyrics with markers like `[INTRO]` and `[DROP]` only.

Expected:
- headers normalized
- missing sections added
- atmosphere injected
- user structure preserved

## Test 3 — Fully formatted lyrics
Paste a fully sectioned lyric.

Expected:
- order preserved
- only atmosphere/timing enhancement
- no section deletion

## Test 4 — Language conversion
Use German lyrics with English mode.

Expected:
- meaning preserved
- natural English lines
- title matches target language logic

## Test 5 — Anti-loop
Use a strong hook and longer structure.

Expected:
- no late restart to intro
- outro feels final
- strongest restart-capable phrase is not placed as the ending trigger

## Test 6 — Title box
Expected:
- title box contains only raw title text
- no label text inside the title box

## Test 7 — Quick controls
Use:
- G4
- V2
- M3
- F5

Expected:
- short controls work cleanly
- user always sees what each code means
