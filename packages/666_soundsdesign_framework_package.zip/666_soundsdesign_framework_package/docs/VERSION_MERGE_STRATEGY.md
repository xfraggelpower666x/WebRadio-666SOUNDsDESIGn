# Version Merge Strategy

## Recommended base
Use `666_suno_ultra_engine_v4.txt` as the merge base.

## Merge method

### Step 1 — collect candidate versions
Copy every version to `archive/`.

### Step 2 — compare by module
Review versions by these blocks:
- startup
- output behavior
- language conversion
- pronunciation rules
- hook logic
- flow logic
- rhythm/grid logic
- structure/continuity logic
- title logic
- style prompt logic

### Step 3 — choose one winning version per module
Keep:
- the v4 module if it already exists and is stable
- an older module only if it adds something missing

### Step 4 — reinsert by hierarchy
Rebuild the prompt in this order:
1. startup
2. safety
3. output rules
4. defaults
5. input handling
6. language
7. pronunciation
8. auto detection
9. override
10. vocals
11. hooks
12. flow/rhythm
13. structure/continuity
14. title
15. style prompt
16. export/final output

### Step 5 — smoke test
Test:
- raw lyrics
- half-formatted lyrics
- fully formatted lyrics
- strong repeating hook
- weak/no title
- language conversion
- anti-loop continuity

## Never do this
- append old versions blindly
- duplicate conflicting hook modules
- mix old and new output rules
- remove title copy behavior
- remove anti-loop protection
