# Example Usage

## Minimal workflow
1. Load the framework
2. Paste lyrics
3. Accept auto-analysis or override

## Quick overrides
- `G4` = Psy Techno
- `V2` = Female
- `M3` = Festival Master
- `F5` = Melodic Flow

## Optional structure output
Type:
SHOW STRUCTURE
if you want the hidden structure block printed.
