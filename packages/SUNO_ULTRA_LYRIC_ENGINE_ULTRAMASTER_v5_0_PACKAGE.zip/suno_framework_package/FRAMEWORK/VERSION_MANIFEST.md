# Version Manifest

## Current authoritative framework

- **Framework Name:** SUNO ULTRA LYRIC ENGINE
- **Current Master Version:** ULTRAMASTER v5.0
- **Engine Version Field:** `ULTRAMASTER_v5_0`
- **Status:** `CONSOLIDATED_ACTIVE`
- **Patch Lineage:** `v4_4_BASE + v4_8_APPEND_MASTER`

## Interpretation

This means:

- v4.4 = structural base
- v4.8 = appended extension/master patch layer
- v5.0 = consolidated current master containing the active merged state

## Operational conclusion

For real usage, **v5.0 should be treated as current**.

Older files should be classified as:

- archive reference
- patch lineage evidence
- fallback recovery source

They should **not** outrank v5.0 unless a newer user-approved master explicitly replaces it.

## Active module count

- 32 modules

## Primary capabilities

- lyric preservation
- hook protection
- identity lock
- phonetic stability
- radio intro presets
- difficult word memory
- structure/timing routing
- review escalation
- token-safe behavior
- intro length classes
- radio identity randomization inside safe bounds

## Current source file

- `FRAMEWORK/SUNO_ULTRA_LYRIC_ENGINE_ULTRAMASTER_v5_0.txt`
