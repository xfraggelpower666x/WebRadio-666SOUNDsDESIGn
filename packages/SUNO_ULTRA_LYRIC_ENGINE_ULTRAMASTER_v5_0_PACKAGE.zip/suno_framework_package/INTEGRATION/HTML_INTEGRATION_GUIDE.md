# HTML / App Integration Guide

## Purpose

This guide shows how to integrate the framework into a website, local app, or prompt-builder UI.

## Recommended architecture

Use three layers:

1. **Framework layer**
   - the master TXT file
2. **User input layer**
   - lyrics, keywords, commands, engine options
3. **Execution layer**
   - ChatGPT/API/system prompt assembly

## Integration options

### Option A — Static embedded string
Good for prototypes and single-file tools.

- copy the TXT file into a JS constant
- prepend it to generation requests

### Option B — Static asset fetch
Best for maintainability.

- keep the TXT file in your project assets
- fetch/load it at runtime
- assemble the final prompt from framework + user input

### Option C — Server-side protected master
Best if you do not want the full engine visible in frontend code.

- store framework TXT on backend
- send it server-side when building the final API prompt

## Recommended file placement in a website project

```text
/assets/framework/SUNO_ULTRA_LYRIC_ENGINE_ULTRAMASTER_v5_0.txt
/js/framework-loader.js
/css/framework-styles.css
/components/framework-panel.html
```

## Frontend workflow

1. load framework text
2. user selects mode (lyrics, keywords, intro, status)
3. user enters content
4. app combines framework + current runtime request
5. app sends assembled prompt to model/API
6. app renders output in protected code/output panels

## Suggested UI controls

- engine status box
- mode selector
- genre field
- BPM field
- preset selector
- intro length selector
- lyrics input area
- output box
- review box

## Critical operational rules

- do not fragment the master logic into random partial snippets unless you maintain a proper build process
- do not edit the master text inside UI widgets by accident
- keep one canonical framework file
- log the framework version in the UI so you always know what is loaded

## Minimum loader pattern

Use the included `framework-loader.js` as a starting point.

## Example flow

- load framework master
- user chooses `GENERATE SONG`
- user enters genre, mood, keywords
- application prepends the framework text
- generation request is sent with framework as the system instruction layer

## Version display recommendation

Always show this somewhere in the UI:

- Framework: ULTRAMASTER v5.0
- Status: CONSOLIDATED_ACTIVE
- Lineage: v4_4_BASE + v4_8_APPEND_MASTER

This avoids confusion later when multiple ZIPs exist.
