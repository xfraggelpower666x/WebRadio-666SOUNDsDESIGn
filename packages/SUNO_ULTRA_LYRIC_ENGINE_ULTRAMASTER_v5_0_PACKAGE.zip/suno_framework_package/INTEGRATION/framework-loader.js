/**
 * Simple framework loader helper.
 *
 * Usage idea:
 * 1. Place the TXT framework file under /assets/framework/
 * 2. Load it with loadFrameworkText()
 * 3. Build a final runtime prompt using buildPromptPayload()
 */

export async function loadFrameworkText(path = "/assets/framework/SUNO_ULTRA_LYRIC_ENGINE_ULTRAMASTER_v5_0.txt") {
  const response = await fetch(path);
  if (!response.ok) {
    throw new Error(`Framework could not be loaded: ${response.status} ${response.statusText}`);
  }
  return await response.text();
}

export function buildPromptPayload({ frameworkText, mode, genre, bpm, preset, introLength, userInput }) {
  const parts = [
    frameworkText?.trim() || "",
    "",
    "====================================================",
    "RUNTIME REQUEST",
    "====================================================",
    mode ? `MODE = ${mode}` : "",
    genre ? `GENRE = ${genre}` : "",
    bpm ? `BPM = ${bpm}` : "",
    preset ? `PRESET = ${preset}` : "",
    introLength ? `INTRO_LENGTH = ${introLength}` : "",
    "",
    "USER INPUT",
    userInput?.trim() || ""
  ].filter(Boolean);

  return parts.join("\n");
}

export function getFrameworkMeta() {
  return {
    name: "SUNO ULTRA LYRIC ENGINE",
    version: "ULTRAMASTER v5.0",
    status: "CONSOLIDATED_ACTIVE",
    lineage: "v4_4_BASE + v4_8_APPEND_MASTER"
  };
}
