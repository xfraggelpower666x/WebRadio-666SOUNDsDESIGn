# Consolidation Strategy for Multiple Framework Versions

## Goal

You said you have several framework versions and are not sure which one is current. This strategy gives you a clean merge process without destroying earlier work.

## Recommended rule hierarchy

1. Latest user-approved consolidated master wins
2. Explicit patch lineage is preserved as documentation
3. Older versions stay archived unchanged
4. New modules append forward, not backward
5. README + manifest always reflect the current winner

## Safe merge process

### Step 1 — Inventory
Collect every framework file you currently have and place them into categories:

- base versions
- append/patch versions
- experimental branches
- final/consolidated versions

Suggested naming:

```text
v4_4_BASE
v4_8_APPEND_MASTER
v5_0_CONSOLIDATED_MASTER
```

### Step 2 — Freeze archives
Do not edit the historical files directly.

Store them in:

```text
/archive
```

### Step 3 — Choose the canonical winner
Use the following decision test:

- Does the file explicitly identify itself as consolidated/master/final?
- Does it preserve previous modules instead of replacing them?
- Does it contain the newest active module registry?
- Does it include the latest phonetic/radio/identity systems?

For the material in this package, the answer is **yes** for v5.0.

### Step 4 — Create one current folder
Only one framework file should live in `/current`.

Right now that should be:

- `SUNO_ULTRA_LYRIC_ENGINE_ULTRAMASTER_v5_0.txt`

### Step 5 — Record lineage
Keep the lineage visible in the manifest:

- base source
- append source
- consolidated result

### Step 6 — Future updates
When you add new modules later, create a new master such as:

```text
SUNO_ULTRA_LYRIC_ENGINE_ULTRAMASTER_v5_1.txt
```

Then update:

- `VERSION_MANIFEST.md`
- `README_START_HERE.md`
- any integration snippets that depend on the filename

## What not to do

Do not:

- overwrite older files without archiving
- mix multiple “current” versions in one folder
- store only fragments without a current master file
- edit version IDs inconsistently
- rename versions casually after they have been referenced elsewhere

## Practical merge rule for your project

For your web-radio/HTML integration workflow, use this policy:

- **Authoritative runtime source:** current TXT master
- **Documentation source:** manifest + README
- **UI integration source:** loader/snippet files
- **Historical research source:** archive folder

## If you later want a true automated merge

The next step would be to provide the actual older framework files. Then they can be diffed and merged into a new authoritative v5.1 package.
