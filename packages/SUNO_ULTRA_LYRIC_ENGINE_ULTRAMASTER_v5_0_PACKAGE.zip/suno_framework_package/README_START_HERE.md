# SUNO ULTRA LYRIC ENGINE — ULTRAMASTER v5.0

This package contains the **current consolidated master** of your framework as represented by the authoritative source text you supplied in this session.

## What this package is

This ZIP is designed to solve three immediate problems:

1. You have multiple framework versions in circulation.
2. You need one clearly marked authoritative master file.
3. You need practical integration notes for adding the framework into your website/app workflow.

## Canonical status

Treat this file as the current master unless you later create a newer authoritative version:

- `FRAMEWORK/SUNO_ULTRA_LYRIC_ENGINE_ULTRAMASTER_v5_0.txt`

## Included contents

- `FRAMEWORK/SUNO_ULTRA_LYRIC_ENGINE_ULTRAMASTER_v5_0.txt` → canonical engine text
- `FRAMEWORK/VERSION_MANIFEST.md` → version identity and what is current
- `MIGRATION/CONSOLIDATION_STRATEGY.md` → how to merge older versions sensibly
- `INTEGRATION/HTML_INTEGRATION_GUIDE.md` → website/app integration notes
- `INTEGRATION/framework-loader.js` → simple loader helper for UI/API projects
- `INTEGRATION/framework-panel-snippet.html` → example menu/panel block
- `INTEGRATION/framework-styles.css` → minimal styles for the framework panel
- `INTEGRATION/sample-api-payload.json` → example payload structure

## Recommended source of truth rule

Use this rule from now on:

- One file = one authoritative framework master
- Older versions are archived, not edited in place
- New changes go into a new versioned master file
- README + manifest must always be updated together

## Recommended naming standard

Use a folder scheme like this:

```text
/Frameworks
  /archive
    SUNO_ULTRA_LYRIC_ENGINE_v4_4.txt
    SUNO_ULTRA_LYRIC_ENGINE_v4_8_APPEND.txt
  /current
    SUNO_ULTRA_LYRIC_ENGINE_ULTRAMASTER_v5_0.txt
  VERSION_MANIFEST.md
```

## Integration concept

This framework is best treated as one of these:

1. **System prompt source** for ChatGPT/API usage
2. **Prompt engine text asset** loaded by your website/app
3. **Protected master config** used by a lyric generation UI

## Practical recommendation for your setup

Given your larger web-radio and framework-integration workflow, the cleanest path is:

- keep this TXT file as the protected master
- load it in your HTML/JS project as a static text asset or embedded string
- send it as the system/runtime instruction layer when generating lyric output
- do not scatter the logic across many disconnected files unless you are intentionally modularizing it

## Important note

This package does **not** automatically compare every older version you may have on disk, because those files were not supplied in this turn. Instead, it packages the currently authoritative v5.0 text and includes a controlled merge strategy for your existing archive.
