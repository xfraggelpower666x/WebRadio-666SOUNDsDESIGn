FRAG.EL FRAMEWORK HOMECODE BUNDLE
=================================

Included files
--------------
1. index.html
   Main homecode integration page with prompt builder and protected identity blocks.
2. engine_runtime_homeframe.txt
   Runtime engine text with integrated phonetic and identity rules.
3. protected_identity_blocks.txt
   Exact protected identity stacks requested by the user.
4. README.txt
   This file.

What was integrated
-------------------
- Fraggel / Fraggle => Frag.el
- Fraggelpower / Fragglepower => Frag.el Power
- Design => dee.sign
- DJ => dee jay
- 666 => exact beat stack only
- Protected identity block 1
- Protected identity block 2
- Radio boot intro flow
- Local save/load in browser
- Prompt builder for testing

Important
---------
The two identity elements are hard-coded and displayed exactly as requested.
The JavaScript also converts matching variants in custom text into the protected forms.
