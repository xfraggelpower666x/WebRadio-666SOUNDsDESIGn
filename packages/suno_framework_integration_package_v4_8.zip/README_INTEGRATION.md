# SUNO ULTRALYRIC ENGINE — HTML Integration Package v4.8

Dieses Paket enthält die Dateien, um den aktuellen Add-Only-Framework-Stand
in eine HTML-Webseite oder ein anderes Frontend zu integrieren.

## Enthaltene Dateien

- `SUNO_ULTRALYRIC_ENGINE_CURRENT_APPEND_PATCH_v4_8.txt`
  - Aktueller Append-Patch als Textdatei.
  - Dieser Patch ist **nicht** die komplette historische Basis.
  - Er ist dafür gedacht, an deine bestehende v4.4/v4.5+ Framework-Basis angehängt zu werden.

- `framework/suno-framework-config.js`
  - Zentrale JavaScript-Konfiguration für Presets, Phonetik, Length Classes und aktive Defaults.

- `framework/suno-framework-api-example.js`
  - Beispielcode, wie du das Framework mit einer Prompt-Pipeline oder API-Anbindung verknüpfen kannst.

- `framework/suno-framework-widget.html`
  - Eigenständiges Demo-Widget mit Auswahlfeldern für Intro-Preset, Length-Class und Ausgabe.

- `framework/suno-framework.css`
  - Einfache Styles für das Demo-Widget.

- `framework/integration-snippet.html`
  - Kleiner HTML-Ausschnitt, den du direkt in eine bestehende Seite einsetzen kannst.

- `README_INTEGRATION.md`
  - Diese Anleitung.

- `INTEGRATION_NOTES.txt`
  - Technische Kurznotizen und Integrationshinweise.

## Wofür dieses Paket gedacht ist

Dieses Paket ist dafür gedacht, im anderen Chat oder direkt im Projekt als
**Integrationsbasis** zu dienen, damit der aktuelle Framework-Stand
nicht wieder manuell zusammengesucht werden muss.

Es deckt vor allem diese Bereiche ab:

- Phonetic Stability
- Beat-basierte 666-Chant-Defaults
- Radio Intro Presets
- Intro Length Control
- Radio Identity Phrase Lock
- Randomizer-konforme Variantenerzeugung

## Wichtige Grundregel

Die aktive Default-Form für die 666-Chant-Ausgabe ist:

(beat)
Six.
(beat)
Six.
(beat)
Six.
(beat)

Die nackte Form `Six. / Six. / Six.` ist **nicht** mehr Default.

## Integrationsvarianten

### Variante A — nur Text-Prompt integrieren

Wenn du nur mit Prompt-Dateien arbeitest:

1. Öffne `SUNO_ULTRALYRIC_ENGINE_CURRENT_APPEND_PATCH_v4_8.txt`
2. Hänge den Inhalt an deine bestehende Framework-Basis an
3. Speichere das Ergebnis als neue Master-Version
4. Nutze die Datei im anderen Chat oder deiner Prompt-Engine

### Variante B — HTML-Webseite mit lokalem Widget

Wenn du in eine HTML-Webseite integrieren willst:

1. Kopiere den Ordner `framework/` in dein Projekt
2. Binde CSS und JavaScript in deiner Seite ein
3. Füge den HTML-Snippet oder das Widget an der gewünschten Stelle ein

Beispiel:

```html
<link rel="stylesheet" href="framework/suno-framework.css" />
<script src="framework/suno-framework-config.js"></script>
<script src="framework/suno-framework-api-example.js"></script>
```

Dann im Body:

```html
<div id="suno-framework-mount"></div>
<script>
  window.renderSunoFrameworkWidget?.("suno-framework-mount");
</script>
```

### Variante C — Integration in bestehende App-Struktur

Wenn du bereits eine bestehende UI mit Tabs, Panels oder Menüpunkten hast:

1. Verwende `suno-framework-config.js` als Datenquelle
2. Lies `window.SunoFrameworkConfig`
3. Nutze die Daten für Dropdowns, Preset-Auswahl und Prompt-Building
4. Nutze `buildSunoPrompt()` aus dem API-Beispiel oder passe die Funktion an

## Empfohlene Einbindung in bestehende Systeme

### Für eine bestehende Radio- oder SongLab-Oberfläche

Empfohlene UI-Bausteine:

- Preset-Auswahl
- Intro-Length-Auswahl
- Spoken/Canonical Toggle
- Button für Prompt-Erzeugung
- Ausgabe-Textfeld oder Copy-Box

### Empfohlene Defaultwerte

- Preset: `PRESET_B`
- Length Class: `RADIO_BOOT_SEQUENCE`
- Spoken Mode: `phonetic`
- 666 Mode: `beat`
- Randomizer: `off` als Standard, optional aktivierbar

## API-/Prompt-Logik

Der Beispielcode baut aus den Einstellungen einen Output-Block auf.
Das ist bewusst einfach gehalten, damit du ihn im anderen Chat oder im Projekt
leicht anpassen kannst.

Typischer Flow:

1. Nutzer wählt Preset
2. Nutzer wählt Length-Class
3. Optional wird Randomizer aktiviert
4. Das System erzeugt einen Intro-Block
5. Der Intro-Block wird zusammen mit dem Append-Patch oder deiner Engine-Basis
   an die Ziel-Pipeline übergeben

## Was du im anderen Chat sagen kannst

Wenn du das Paket in einem anderen Chat weiterverwenden willst, reicht ungefähr:

- Nutze den Append-Patch aus der TXT-Datei als aktuellen Framework-Zusatz
- Nutze die JS-Konfiguration als aktuelle Datenbasis
- Behalte Beat-Chant als aktiven Standard
- Behalte fray-gel / fray-gelPOWER als phonetic default
- Nutze PRESET_B als Standard-Webradio-Boot-Intro

## Technische Hinweise

- Alle Dateien sind bewusst plain HTML/CSS/JS gehalten
- Keine Build-Tools nötig
- Kein Framework-Zwang
- Direkt in statische Webseiten integrierbar
- Kann später in React/Vue/Plain JS migriert werden

## Wichtige Klarstellung

Dieses Paket enthält einen **praktischen Integrationsstand**.
Es rekonstruiert nicht automatisch jede historische Zwischenversion deines
Frameworks, sondern bildet den hier besprochenen aktuellen Add-Only-Stand
als Integrationspaket ab.

## Empfohlener nächster Schritt

Im anderen Chat kannst du dieses Paket verwenden, um daraus:

- einen eigenen Menüpunkt
- ein SongLab-Modul
- ein Prompt-Builder-Panel
- oder eine API-gekoppelte Intro-Engine

zu machen.
