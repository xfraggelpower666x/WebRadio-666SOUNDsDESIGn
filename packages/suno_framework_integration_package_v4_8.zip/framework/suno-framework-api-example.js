(function () {
  function applyChantMode(text, chantMode, config) {
    if (chantMode === "beat") {
      return text.replace(/Six\.\nSix\.\nSix\./g, config.chants.beat);
    }
    return text.replace(config.chants.beat, config.chants.plain);
  }

  function buildSunoPrompt(options) {
    const config = window.SunoFrameworkConfig;
    const presetKey = options?.preset || config.activeDefaults.preset;
    const introLengthClass = options?.introLengthClass || config.activeDefaults.introLengthClass;
    const chantMode = options?.chantMode || config.activeDefaults.chantMode;
    const pronunciationMode = options?.pronunciationMode || config.activeDefaults.pronunciationMode;
    const randomizer = Boolean(options?.randomizer);

    let text = config.presets[presetKey]?.text || config.presets[config.activeDefaults.preset].text;
    text = applyChantMode(text, chantMode, config);

    const header = [
      "SUNO FRAMEWORK OUTPUT",
      `preset = ${presetKey}`,
      `intro_length_class = ${introLengthClass}`,
      `pronunciation_mode = ${pronunciationMode}`,
      `chant_mode = ${chantMode}`,
      `randomizer = ${randomizer ? "on" : "off"}`,
      ""
    ].join("\n");

    return `${header}\n${text}`.trim();
  }

  function renderSunoFrameworkWidget(mountId) {
    const mount = document.getElementById(mountId);
    if (!mount || !window.SunoFrameworkConfig) return;

    const config = window.SunoFrameworkConfig;
    mount.innerHTML = `
      <div class="suno-widget">
        <h2>SUNO Framework Integration</h2>
        <div class="suno-row">
          <label>Preset</label>
          <select id="suno-preset"></select>
        </div>
        <div class="suno-row">
          <label>Intro Length</label>
          <select id="suno-length"></select>
        </div>
        <div class="suno-row">
          <label>Chant Mode</label>
          <select id="suno-chant">
            <option value="beat">Beat</option>
            <option value="plain">Plain</option>
          </select>
        </div>
        <div class="suno-row">
          <label>Pronunciation</label>
          <select id="suno-pronunciation">
            <option value="phonetic">Phonetic</option>
            <option value="canonical">Canonical</option>
          </select>
        </div>
        <div class="suno-row checkbox-row">
          <label><input type="checkbox" id="suno-randomizer" /> Enable Randomizer Flag</label>
        </div>
        <div class="suno-row">
          <button id="suno-generate">Generate Output</button>
        </div>
        <div class="suno-row">
          <textarea id="suno-output" rows="18" spellcheck="false"></textarea>
        </div>
      </div>
    `;

    const presetSelect = mount.querySelector("#suno-preset");
    const lengthSelect = mount.querySelector("#suno-length");
    const chantSelect = mount.querySelector("#suno-chant");
    const pronunciationSelect = mount.querySelector("#suno-pronunciation");
    const randomizerCheckbox = mount.querySelector("#suno-randomizer");
    const output = mount.querySelector("#suno-output");

    Object.entries(config.presets).forEach(([key, value]) => {
      const opt = document.createElement("option");
      opt.value = key;
      opt.textContent = `${key} — ${value.label}`;
      if (key === config.activeDefaults.preset) opt.selected = true;
      presetSelect.appendChild(opt);
    });

    Object.entries(config.introLengthClasses).forEach(([key, value]) => {
      const opt = document.createElement("option");
      opt.value = key;
      opt.textContent = `${key} — ${value.label} (${value.target})`;
      if (key === config.activeDefaults.introLengthClass) opt.selected = true;
      lengthSelect.appendChild(opt);
    });

    chantSelect.value = config.activeDefaults.chantMode;
    pronunciationSelect.value = config.activeDefaults.pronunciationMode;
    randomizerCheckbox.checked = config.activeDefaults.randomizer;

    function generate() {
      output.value = buildSunoPrompt({
        preset: presetSelect.value,
        introLengthClass: lengthSelect.value,
        chantMode: chantSelect.value,
        pronunciationMode: pronunciationSelect.value,
        randomizer: randomizerCheckbox.checked
      });
    }

    mount.querySelector("#suno-generate").addEventListener("click", generate);
    generate();
  }

  window.buildSunoPrompt = buildSunoPrompt;
  window.renderSunoFrameworkWidget = renderSunoFrameworkWidget;
})();
