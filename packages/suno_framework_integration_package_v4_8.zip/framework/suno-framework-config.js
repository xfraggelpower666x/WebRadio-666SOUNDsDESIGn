(function () {
  const BEAT_CHANT = `(beat)
Six.
(beat)
Six.
(beat)
Six.
(beat)`;

  const SunoFrameworkConfig = {
    version: "v4.8",
    activeDefaults: {
      preset: "PRESET_B",
      introLengthClass: "RADIO_BOOT_SEQUENCE",
      pronunciationMode: "phonetic",
      chantMode: "beat",
      randomizer: false
    },
    phoneticMap: {
      FRAGGEL: "fray-gel",
      FRAGGELPOWER: "fray-gelPOWER",
      "666 SOUNDsDESIGn": "six six six sounds design",
      "666 Sounds Design": "six six six sounds design",
      DJ: "dee jay",
      Broadcaster: "broad-caster",
      "Digital Underground Connected": "digital underground connected",
      "Neon Music Galaxy": "neon music galaxy"
    },
    chants: {
      beat: BEAT_CHANT,
      plain: `Six.
Six.
Six.`
    },
    introLengthClasses: {
      ULTRA_SHORT_IDENT: {
        label: "Ultra Short Ident",
        target: "2–4 seconds"
      },
      SHORT_STATION_IDENT: {
        label: "Short Station Ident",
        target: "5–10 seconds"
      },
      RADIO_BOOT_SEQUENCE: {
        label: "Radio Boot Sequence",
        target: "10–20 seconds"
      },
      CINEMATIC_SYSTEM_INTRO: {
        label: "Cinematic System Intro",
        target: "20–45 seconds"
      }
    },
    presets: {
      PRESET_A: {
        label: "Minimal Station Ident",
        text: `(2s pause)

[INTRO – station ident]

dee jay fray-gel

also known as

fray-gelPOWER

signal locked

system online`
      },
      PRESET_B: {
        label: "Brutal 666 Boot Intro",
        text: `(2s pause)

[INTRO – neon transmission]

dee jay fray-gel

also known as

fray-gelPOWER

${BEAT_CHANT}

signal locked

target identified

digital underground connected

system online`
      },
      PRESET_C: {
        label: "System Transmission Intro",
        text: `(2s pause)

[INTRO – industrial transmission]

(low machine rumble)

dee jay fray-gel

fray-gelPOWER

${BEAT_CHANT}

(beat)

system awake

(beat)

frequency rising

(beat)

enter the system`
      }
    }
  };

  window.SunoFrameworkConfig = SunoFrameworkConfig;
})();
