# SUNO ULTRA LYRIC ENGINE — Merge & Integration Package

Dieses Paket ist als **nicht-destruktive Merge-Basis** gedacht, damit mehrere Framework-Versionen sauber zusammengeführt werden können — auch dann, wenn mehrere **V5/S5-Varianten** existieren.

## Ziel

Die Zusammenführung soll **Versionen nicht überschreiben**, sondern in eine klare Struktur bringen:

- **Originale behalten**
- **eine aktive Default-Version definieren**
- **Varianten dokumentieren**
- **Regeln zentralisieren**
- **Konflikte sichtbar machen**
- **später gezielt einzelne Blöcke mergen**

## Paketinhalt

- `frameworks/FINAL_FAST_PRODUCTION_PROMPT_S5.txt`
  - die aktuelle Fast-Production-Basis
- `merge/UNIFIED_MASTER_MERGE_WRAPPER.txt`
  - Wrapper-Konzept, um mehrere Versionen parallel zu führen
- `merge/FRAMEWORK_MERGE_STRATEGY.md`
  - konkrete Merge-Logik
- `merge/FRAMEWORK_VERSION_REGISTRY_TEMPLATE.json`
  - Registry für mehrere Versionen und V5-Varianten
- `docs/CHANGELOG_TEMPLATE.md`
  - Vorlage für nachvollziehbare Änderungen

## Empfohlene Zielstruktur

```text
/SUNO_ENGINE/
  /archive/
    v4_4.txt
    v4_8.txt
    v5_a.txt
    v5_b.txt
    v5_fast_production.txt
  /active/
    MASTER_WRAPPER.txt
    DEFAULT_ENGINE.txt
  /registry/
    framework_version_registry.json
  /docs/
    README_INTEGRATION.md
    CHANGELOG.md
    MERGE_NOTES.md
```

## Integrationsprinzip

### 1. Alle Versionen zuerst archivieren

Lege **jede vorhandene Framework-Datei unverändert** in `archive/` ab.

Wichtig:
- nichts direkt überschreiben
- keine Zeilen verlieren
- keine Kürzungen vor dem Vergleich
- gleiche Hauptversionen mit Suffix unterscheiden

Beispiel:
- `v5_a.txt`
- `v5_b.txt`
- `v5_fast_production.txt`
- `v5_runtime_safe.txt`

### 2. Registry pflegen

Trage jede Version in die Registry ein:
- Dateiname
- Engine-Typ
- Version
- Zweck
- Status
- Priorität
- bekannte Konflikte

Dafür ist die JSON-Vorlage im Paket gedacht.

### 3. Wrapper als aktive Einstiegsebene nutzen

`UNIFIED_MASTER_MERGE_WRAPPER.txt` dient als **oberste Koordinationsschicht**.

Der Wrapper soll:
- die Standardengine definieren
- erlaubte Overrides definieren
- mehrere V5-Varianten unterscheiden
- Prioritäten zwischen Versionen festlegen
- Konflikte ohne Datenverlust abfangen

### 4. Eine aktive Default-Datei setzen

Nutze die aktuell bevorzugte Datei als:

- `DEFAULT_ENGINE.txt`

Am Anfang empfehle ich als aktive Basis:

- `FINAL_FAST_PRODUCTION_PROMPT_S5.txt`

### 5. Merge nur modulweise

Nicht komplette Dateien blind mischen. Stattdessen nur blockweise prüfen:

- Runtime Mode
- Defaults
- Output Rules
- Structure Model
- Timing Model
- Preservation Rules
- Phonetic Protection
- Genre Logic
- Vocal Instructions
- Final Output Format

## Merge-Regeln für mehrere V5-Versionen

Wenn mehrere V5-Versionen existieren, nutze diese Priorisierung:

### Behalten
Alles behalten, wenn die Blöcke sich nicht widersprechen.

### Zusammenführen
Nur dann zusammenführen, wenn:
- gleiche Funktion
- gleicher Kontext
- gleiche Zielausgabe
- keine harte Regelkollision

### Trennen
Als separate Variante behalten, wenn:
- andere Runtime-Philosophie
- andere Output-Struktur
- andere Timing-Logik
- andere Kürzungslogik
- andere Ziel-Suno-Version

## Sinnvolle Benennung für V5-Varianten

Empfohlen:

- `S5_FAST_PRODUCTION`
- `S5_FULL_STRUCTURE`
- `S5_CONVERSION_SAFE`
- `S5_RADIO_INTRO`
- `S5_LONGFORM_CINEMATIC`

So bleibt eine V5-Familie verständlich.

## Praktischer Merge-Ablauf

1. Alle alten Versionen sammeln
2. Unverändert archivieren
3. Registry ausfüllen
4. Unterschiede blockweise markieren
5. Konflikte notieren
6. Wrapper definieren
7. aktive Standardversion festlegen
8. Spezialvarianten separat behalten
9. erst danach eine konsolidierte Master-Version bauen

## Konfliktbehandlung

Typische Konflikte:

- unterschiedliche Zahl von Codeboxen
- unterschiedliche Runtime-Längen
- aggressive vs minimale Kürzung
- verschiedene Strukturmodelle
- unterschiedliche phonetic protection rules
- verschiedene Engine-Namen oder Version Labels

Regel:
**Bei Konflikt niemals blind überschreiben.**
Stattdessen:
- Konflikt dokumentieren
- stärkere/neuere Regel im Wrapper priorisieren
- ältere Regel im Archiv behalten

## Empfehlung für deine Situation

Da du vermutlich mehrere V5-Versionen hast, ist die sauberste Lösung:

- **eine Default-V5**
- **mehrere spezialisierte V5-Subvarianten**
- **ein Wrapper oben drüber**
- **eine Registry für Nachvollziehbarkeit**

## Nächster sinnvoller Schritt

Sobald du deine anderen Framework-Versionen gesammelt hast, können sie nach diesem Schema eingeordnet werden. Dann lässt sich daraus eine echte **konsolidierte Master-Datei** bauen, ohne dass alte Logik verloren geht.
