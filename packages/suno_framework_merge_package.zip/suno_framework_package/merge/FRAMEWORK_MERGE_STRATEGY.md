# Framework Merge Strategy

## Grundregel

Nicht-destruktiver Merge.

Das bedeutet:
- keine Version verwerfen
- keine Altdatei löschen
- keine Regel stillschweigend überschreiben
- keine Kürzung ohne dokumentierte Entscheidung

## Merge-Ebenen

### Ebene 1 — Archiv
Alle Originalfassungen bleiben erhalten.

### Ebene 2 — Registry
Alle Versionen werden mit Metadaten erfasst.

### Ebene 3 — Wrapper
Der Wrapper steuert, welche Version standardmäßig aktiv ist und welche Spezialfälle wohin geroutet werden.

### Ebene 4 — Konsolidierung
Erst nach Dokumentation aller Unterschiede wird eine Master-Version erzeugt.

## Entscheidungslogik pro Block

Für jeden Block einer Datei folgende Prüfung:

1. Existiert derselbe Block in anderen Versionen?
2. Ist die Funktion identisch?
3. Ist nur die Formulierung anders oder auch die Regel?
4. Ist die neue Fassung präziser oder nur kürzer?
5. Führt die Änderung zu einem echten Verhaltensunterschied?

## Block-Kategorien

- Identity / Engine Header
- Runtime Instructions
- Defaults
- Input Handling
- Output Rules
- Timing / Runtime Targets
- Structure Model
- Preservation Rules
- Genre Logic
- Phonetic Protection
- Conversion Rules
- Keyword Expansion Rules
- Final Output Format

## Merge-Entscheidungsmatrix

### Fall A — Inhalt gleich, nur anders formuliert
=> präzisere Fassung übernehmen, alte im Archiv lassen

### Fall B — Inhalt ergänzt bestehende Funktion sauber
=> zusammenführen

### Fall C — Inhalt widerspricht harter Regel
=> nicht direkt mergen, als Konflikt markieren

### Fall D — Inhalt ist Spezialmodus
=> separate Variante anlegen

## Beispiel: mehrere V5-Versionen

Wenn du mehrere V5-Versionen hast:

- eine V5-Version kann für Fast Production optimiert sein
- eine andere für lange Cinematic Intros
- eine weitere für Conversion vorhandener Lyrics

Diese Versionen sollten nicht zwangsweise in eine einzige Datei gepresst werden.

Besser:
- gemeinsame Kernregeln zentralisieren
- Spezialverhalten als Variante erhalten

## Was zentralisiert werden kann

Typisch zentralisierbar:
- Phonetic Protection
- Output Box Count
- Engine Default
- Preservation Rules
- Final Quality Check

## Was oft variantenspezifisch bleiben sollte

- Runtime-Ziellänge
- Intro-Länge
- Strukturmodell
- Genre-Fokus
- spezielle Hook-Systeme
- Radio-Intro-Logik

## Konsolidierte Master-Datei

Eine konsolidierte Master-Datei sollte nur dann gebaut werden, wenn:
- alle Varianten inventarisiert sind
- Konflikte dokumentiert sind
- klar ist, welche Regeln global gelten
- klar ist, welche Regeln nur für Spezialmodi gelten

## Empfohlene Regelpriorität

1. Manual Override
2. Explicit User Commands
3. Active Variant Rules
4. Shared Core Rules
5. Legacy Compatible Rules
6. Default Behavior
