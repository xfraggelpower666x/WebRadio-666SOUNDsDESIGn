# SUNO Prompt Engine Bundle

Dieses ZIP enthält den vollständigen Master-Prompt für dein Suno-System sowie Hinweise zur Integration in ein bestehendes Framework-System.

## Inhalt

- `prompts/SUNO_ULTRA_MASTER_PROMPT.txt`
  - vollständiger Master-Prompt
- `docs/INTEGRATION_GUIDE.md`
  - Integrationshinweise für bestehende Prompt-/Framework-Systeme
- `docs/VARIABLE_REFERENCE.md`
  - alle Variablen, Codes und Regeln im Überblick
- `examples/EXAMPLE_MINIMAL_INPUT.txt`
  - Minimalbeispiel
- `examples/EXAMPLE_FULL_INPUT.txt`
  - vollständiges Beispiel mit System-Test-Modus

## Zweck

Das System ist dafür gedacht, aus einer kompakten Variablen-Eingabe und einem Lyrics-/Script-Block automatisch drei Suno-kompatible Codeboxen zu erzeugen:

1. Titel
2. Style-Prompt
3. Lyrics / Script

## Harte Regeln

- Suno V5 / V4.5 kompatibel
- Style-Prompt maximal 1000 Zeichen
- Lyrics niemals kürzen
- Lyrics niemals zusammenfassen
- Struktur des Scripts beibehalten
- Tracklänge zwischen 5:50 und 7:30
- Intro exakt 1:20
- Outro exakt 1:20

## Empfehlung zur Nutzung

Wenn du das System in ein bestehendes Framework einhängst, nutze den Prompt als zentrale Engine-Datei und übergib nur noch:

- Variablenblock
- Lyrics-/Script-Block

## Schnellstart

Minimal:

```text
X=1
Y=11

L=
(dein Script)
```

Vollständig:

```text
T=Warehouse Diagnostic
B=140
G=3
V=3
E=3
M=3
X=1
Y=11

L=
(dein Script)
```
