# Integrationshinweise für bestehende Framework-Systeme

## Ziel

Der Master-Prompt ist als eigenständige Engine gedacht. Er kann in ein bestehendes Framework-System integriert werden, ohne dass vorhandene State-Logik, Routing-Logik oder UI-Logik zerstört werden muss.

## Empfohlene Einbindung

### 1. Rolle des Prompts im Framework

Der Prompt sollte als **Output-Engine** oder **Compilation-Engine** behandelt werden.

Er ist **nicht**:
- die komplette UI
- nicht das komplette Workflow-System
- nicht der vollständige State-Manager

Er ist:
- die Engine, die aus Eingabeparametern + Lyrics/Script ein standardisiertes Suno-Outputformat erzeugt

## 2. Empfohlene Architektur

### Input Layer
Nimmt entgegen:
- Variablen (`T, B, G, V, E, M, X, Y`)
- Lyrics-/Script-Block (`L=`)

### Validation Layer
Prüft:
- sind Pflichtblöcke vorhanden?
- ist der Style-Prompt später auf 1000 Zeichen begrenzt?
- ist die Timing-Logik zulässig?

### Prompt Engine Layer
Verwendet den Inhalt aus `prompts/SUNO_ULTRA_MASTER_PROMPT.txt` unverändert.

### Output Layer
Gibt exakt drei Codeboxen aus:
1. Titel
2. Style-Prompt
3. Lyrics / Script

## 3. Nicht tun

Bei der Integration **nicht**:
- den Lyrics-Block zusammenfassen
- Wiederholungen entfernen
- Zeilen automatisch „verbessern“
- Strukturblöcke umsortieren
- Timing-Blöcke löschen

## 4. Harte Integrationsregel

Wenn Nutzer ein Script vorgeben, muss Box 3 das Script **inhaltlich vollständig** beibehalten.

Erlaubt sind nur:
- Syntax-Korrekturen entsprechend der definierten Syntax-Engine
- Ergänzung fehlender Zeit/Atmosphäre/Bracket-Formatierung, wenn diese im Modus Auto-Correction aktiviert ist

Nicht erlaubt sind:
- Kürzungen
- kreative Umschreibungen
- Verdichtung
- Zusammenfassung

## 5. Timing-Integration

Das Framework sollte diese Grenzen global respektieren:

- minimale Länge: 5:50
- maximale Länge: 7:30
- Intro: 1:20
- Outro: 1:20

Wenn ein externes System Section-Timings vergibt, müssen diese mit dem Master-Prompt kompatibel bleiben.

## 6. Spezialfall System-Test-Track

Wenn `X=1` gesetzt ist, soll das Framework den Prompt als System-Diagnose-Engine behandeln.

Wenn zusätzlich `Y=11` gesetzt ist, müssen folgende Module bevorzugt werden:

- Computer boot
- Sound system test
- DJ console test
- Stereo channel calibration
- Frequency diagnostic
- Subwoofer calibration
- Lighting system test
- Laser system test
- Fog system test
- Dolby style surround speaker test

## 7. Beispiel für Framework-Einbindung

```text
FRAMEWORK INPUT
  -> variable parser
  -> lyrics/script collector
  -> master prompt injection
  -> output formatter
  -> 3 code boxes
```

## 8. Dateipfad-Empfehlung

Wenn dein bestehendes Framework mit Modulen arbeitet, ist diese Struktur sinnvoll:

```text
/framework
  /engines
    SUNO_ULTRA_MASTER_PROMPT.txt
  /schemas
    VARIABLE_REFERENCE.md
  /examples
    EXAMPLE_FULL_INPUT.txt
```

## 9. Versionierung

Empfohlen:
- Prompt-Datei versionieren
- Änderungen nur append-only dokumentieren
- Originalprompt nie stillschweigend überschreiben

## 10. Praxisempfehlung

Wenn du mehrere Prompts oder Engines in einem System nutzt, behandle diese Engine als:

- `SunoOutputEngine`
- `SunoDiagnosticTrackEngine`
- oder `SunoTrackCompiler`

Damit bleibt die Trennung zu UI-, State- und Review-Modulen sauber.
