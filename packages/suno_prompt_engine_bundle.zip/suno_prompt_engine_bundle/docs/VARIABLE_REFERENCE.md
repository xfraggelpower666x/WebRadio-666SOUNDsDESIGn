# Variablen-Referenz

## Eingabevariablen

- `T` = Title
- `B` = BPM
- `G` = Genre
- `V` = Vocal mode
- `E` = Energy style
- `M` = Track mode
- `X` = Special track engine
- `Y` = Test modules
- `L` = Lyrics / Script

## Genre Codes

- `1` = Dark Techno
- `2` = Hypnotic Techno
- `3` = Trance Techno
- `4` = Industrial Techno
- `5` = Melodic Techno
- `6` = Electro Techno
- `7` = Cinematic Techno
- `8` = Hard Techno
- `9` = Auto detect

## Vocal Mode Codes

- `1` = Sung vocals
- `2` = Robotic system voice
- `3` = Mixed vocals and robotic voice
- `4` = Whisper voice
- `5` = Auto detect

## Energy Style Codes

- `1` = Deep
- `2` = Driving
- `3` = Warehouse
- `4` = Peak time
- `5` = Psychedelic
- `6` = Cinematic
- `7` = Auto detect

## Track Mode Codes

- `1` = Club track
- `2` = Radio intro
- `3` = System diagnostic track
- `4` = DJ set opener
- `5` = Cinematic intro
- `6` = Auto detect

## Special Track Engine `X`

- `0` = normal track
- `1` = system diagnostic track
- `2` = club system test intro
- `3` = radio broadcast intro
- `4` = cinematic intro
- `5` = DJ set opener
- `6` = auto detect

## Test Modules `Y`

- `1` = Computer boot
- `2` = Sound system test
- `3` = Light system test
- `4` = Dolby style surround test
- `5` = DJ console test
- `6` = Laser system test
- `7` = Fog system test
- `8` = Stereo channel test
- `9` = Frequency diagnostic
- `10` = Subwoofer calibration
- `11` = Full club diagnostic
- `12` = Auto detect

## Timing Rules

- Track minimum: `5:50`
- Track maximum: `7:30`
- Intro: `1:20`
- Outro: `1:20`

## Lyrics Syntax Engine

### Runde Klammern `( )`
Nutzen für:
- Zeitbereich
- Section-Name
- Atmosphäre

Format:

```text
(0:00–1:20 | Section: Intro | Atmosphere: dark underground warehouse)
```

### Eckige Klammern `[ ]`
Nutzen für:
- Voice-Anweisungen
- Sound-Anweisungen
- Music-Anweisungen

Beispiele:

```text
[Voice: robotic system]
[Sound: diagnostic test beep]
[Music: hypnotic dark techno groove]
```
