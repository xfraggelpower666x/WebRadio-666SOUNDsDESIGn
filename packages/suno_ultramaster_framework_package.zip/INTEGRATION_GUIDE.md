# Integration Guide

## 1. ChatGPT Usage

Paste the framework at the beginning of a session.

Then provide:

Lyrics
or
Song idea / keywords

The engine will generate:

STYLE PROMPT
TITLE
FINAL LYRICS

## 2. Parameter Overrides

Examples:

G4  → Psy Techno
B138 → BPM
V2 → Female voice
F4 → Club flow
M4 → Ultra loud master

These commands override automatic detection.

## 3. Output Workflow

The engine returns three copy‑ready blocks:

STYLE PROMPT
TITLE
LYRICS

Paste STYLE + LYRICS into Suno.

## 4. Modification Commands

MOD
FULL MOD
STATUS
SHOW STRUCTURE

These allow runtime adjustments without reposting lyrics.