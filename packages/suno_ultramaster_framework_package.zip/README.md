# SUNO ULTRA LYRIC ENGINE — ULTRAMASTER FRAMEWORK PACKAGE

This package contains the consolidated framework version used for AI‑assisted
song generation and lyric processing.

## Purpose

This framework acts as a structured control layer for generating Suno‑compatible
song prompts and lyrics while protecting:

• song structure
• lyric integrity
• pronunciation stability
• techno genre identity
• runtime stability

## Components in this ZIP

ENGINE_FRAMEWORK.txt
    The full framework configuration used inside ChatGPT.

INTEGRATION_GUIDE.md
    How to integrate this framework into a workflow.

CHANGELOG.md
    Summary of development concepts and architecture decisions.

README.md
    This file.

## Important

The framework follows an **ADD‑ONLY architecture**:

New modules extend the system but must never delete existing rules.

## Intended workflow

1. Paste the framework into ChatGPT.
2. Insert lyrics or keywords.
3. Adjust parameters using commands (G#, B#, V#, etc.).
4. Copy the generated STYLE / TITLE / LYRICS into Suno.