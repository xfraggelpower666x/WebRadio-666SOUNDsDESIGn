# 666 GOVEE WORKER v0.2 — isolierter CodeForge-Kandidat

Aus dem realen v1-Quellpaket abgeleitet, die vorhandenen API-Pfade bleiben erhalten. Ergänzt `/api/groups/control` für *flüchtig ausgewählte*, begrenzte Gruppen (keine persistierten Gruppen) sowie `/api/audio/preview` zur rein berechnenden Audio-Szenen-Transformation ohne Lampenkommando. Zwei Geräteregionen H6047/H6198 ergeben sich aus den wirklichen Govee-Capabilities; keine fest codierten MACs oder Geräte-IDs. Gruppensenden sequenziell, Teilergebnisse gemeldet; Govee-Limits beachten. Es gibt **noch keine** Live-Cloud- oder Lampenprüfung.

`npm test && npm run check` testet lokal mit Node 22. Die beiden Secrets `GOVEE_API_KEY` und `CONTROL_TOKEN` gehören ausschließlich in Cloudflare-Secret-Bindings, niemals in öffentliche Browser-Skripte.

## Gates

- WORKER_RELEASE=NO. Dieser Kandidat ist **nicht live deployt**.
- Authentifizierter Geräte-Capability-Readback und API-Payload-Validierung fehlen.
- Für produktive Gruppenbefehle erst vollständige Typ-/Wertevalidierung anhand der echten Capability-Parameter ergänzen.
- Audioanalyse bleibt in der Quellanwendung; die Cloud-API ist kein Audio-Frame-Transport.
- Kein API-Key, Token, APK-Binary oder aus APK extrahierter Source Bestandteil dieses Pakets.
