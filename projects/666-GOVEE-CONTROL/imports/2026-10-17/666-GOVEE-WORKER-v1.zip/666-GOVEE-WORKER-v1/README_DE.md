# 666 GOVEE WORKER v1.0

Cloudflare Worker für die offizielle Govee Developer OpenAPI. Separater Worker; kein Patch an bestehenden Radio-Workern. Keine Python-/LAN-Bridge erforderlich für die Cloud-API. Geräte müssen von Govee per Cloud-API gemeldet werden. Die LAN-Audioreaktivität ist nicht Teil dieses Workers.

## Einrichten
1. Cloudflare Dashboard → Workers & Pages → `666-govee-control` (oder mit Wrangler bereitstellen).
2. Unter **Settings → Variables and Secrets** die verschlüsselten **Secrets** `GOVEE_API_KEY` und `CONTROL_TOKEN` setzen. `CONTROL_TOKEN` ist ein eigenes langes zufälliges Passwort, nicht der Govee-Key. Optional `ALLOWED_ORIGIN` für eine einzelne vertrauenswürdige Webseite. Keine Secrets ins GitHub-Repository oder Browser-JavaScript kopieren.
3. `GET /health` ohne Token zeigt, ob die Secrets konfiguriert sind (nicht ihre Werte).
4. `GET /api/devices` mit `Authorization: Bearer <CONTROL_TOKEN>` liefert echte Govee-Geräte samt capabilities. Erst danach IDs und geeignete Kontrollwerte ermitteln.
5. `POST /api/state` mit `{ "sku":"H6047", "device":"<Govee-Geräte-ID>" }` fragt den Zustand ab.
6. `POST /api/control` mit `{ "sku":"H6047", "device":"<Govee-Geräte-ID>", "capability":{"type":"devices.capabilities.on_off","instance":"powerSwitch","value":1} }` steuert nur bestätigte Fähigkeiten. H6198 analog mit tatsächlich von Govee gelieferter Geräte-ID.

**ACHTUNG:** Das `CONTROL_TOKEN` darf NICHT fest in einer öffentlichen WebRadio-Webseite hinterlegt werden. Für die Radio-Anbindung braucht es eine serverseitige Authentifizierungssitzung oder eine separate zugriffsgeschützte Admin-Oberfläche. Browser-CORS ist kein Authentifizierungsersatz. Ohne sicheren Zugriff keine öffentliche Steuerung.

## Grenzen
- Cloud-API ist für Grundbefehle, nicht für Beat-für-Beat-Audioreaktivität geeignet.
- Der Worker verifiziert die Gerätezugehörigkeit und die gemeldete Capability vor jedem Steuerbefehl; dies kostet zusätzliche Geräteabfragen. Produktionsbetrieb benötigt später sicheres Caching und Rate-Limiting.
- Bei fehlenden Secrets gesperrt (503); ohne gültiges Token 401.
- Keine garantierte Kostenfreiheit über Cloudflare Free-Tier-/Govee-Nutzungsgrenzen hinaus; keine kostenpflichtigen Ressourcen im Paket.
- Erst nach Live-Readback gilt Gerätefunktion als verifiziert.
