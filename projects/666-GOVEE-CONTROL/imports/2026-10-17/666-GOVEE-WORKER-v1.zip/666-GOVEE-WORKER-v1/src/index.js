// 666SOUNDsDESIGn · GOVEE CLOUD CONTROL · v1.0
// Official Govee Developer OpenAPI; secrets never exposed to clients.
const BASE = 'https://openapi.api.govee.com';
const HEADERS = { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', 'x-content-type-options': 'nosniff' };
const json = (body, status=200, extra={}) => new Response(JSON.stringify(body), {status, headers:{...HEADERS,...extra}});
const fail = (status, error) => json({ok:false,error},status);
function equal(a,b){if(typeof a!=='string'||typeof b!=='string')return false;const x=new TextEncoder().encode(a),y=new TextEncoder().encode(b);let bad=x.length^y.length;for(let i=0;i<Math.max(x.length,y.length);i++)bad|=(x[i]||0)^(y[i]||0);return bad===0;}
function cors(request,env){const origin=request.headers.get('Origin');return origin&&env.ALLOWED_ORIGIN&&origin===env.ALLOWED_ORIGIN?{'access-control-allow-origin':origin,'vary':'Origin','access-control-allow-headers':'authorization,content-type','access-control-allow-methods':'GET,POST,OPTIONS'}:{};}
async function govee(env,path,method='GET',body){const res=await fetch(BASE+path,{method,headers:{'Govee-API-Key':env.GOVEE_API_KEY,'Content-Type':'application/json'},...(body?{body:JSON.stringify(body)}:{})});const result=await res.json().catch(()=>null);if(!res.ok)return {ok:false,httpStatus:res.status,error:'Govee upstream error',upstreamCode:result?.code??null};return {ok:true,result};}
const isSku=x=>typeof x==='string'&&/^H[0-9A-Z]{4,10}$/.test(x);
const isDevice=x=>typeof x==='string'&&/^[0-9A-Fa-f:]{12,35}$/.test(x);
const typeName=x=>typeof x==='string'&&/^devices\.capabilities\.[a-z_]{2,60}$/.test(x);
const instanceName=x=>typeof x==='string'&&/^[a-zA-Z][a-zA-Z0-9_]{0,60}$/.test(x);
async function owned(env){const r=await govee(env,'/router/api/v1/user/devices');if(!r.ok)return r;const devices=r.result?.data?.devices??r.result?.payload?.devices??[];return {ok:true,devices:Array.isArray(devices)?devices:[]};}
export default {async fetch(request,env){
 const u=new URL(request.url), headers=cors(request,env);
 const respond=(body,status=200)=>json(body,status,headers);
 if(request.method==='OPTIONS')return Object.keys(headers).length?new Response(null,{status:204,headers}):fail(403,'Origin not permitted');
 if(u.pathname==='/health'&&request.method==='GET')return respond({ok:true,service:'666-govee-worker',version:'1.0',configured:!!env.GOVEE_API_KEY,locked:!env.CONTROL_TOKEN});
 if(!env.GOVEE_API_KEY||!env.CONTROL_TOKEN)return respond({ok:false,error:'Required secrets not configured'},503);
 const authorization=request.headers.get('Authorization')||'';
 if(!equal(authorization,'Bearer '+env.CONTROL_TOKEN))return respond({ok:false,error:'Unauthorized'},401);
 try {
  if(u.pathname==='/api/devices'&&request.method==='GET'){
   const r=await owned(env);if(!r.ok)return respond(r,502);
   return respond({ok:true,devices:r.devices.map(d=>({sku:d.sku,device:d.device,deviceName:d.deviceName,capabilities:d.capabilities}))});
  }
  if(u.pathname==='/api/state'&&request.method==='POST'){
   const body=await request.json().catch(()=>null);
   if(!body||!isSku(body.sku)||!isDevice(body.device))return respond({ok:false,error:'Invalid device identification'},400);
   const r=await owned(env);if(!r.ok)return respond(r,502);
   if(!r.devices.some(x=>x.sku===body.sku&&x.device===body.device))return respond({ok:false,error:'Device not registered to account'},403);
   const s=await govee(env,'/router/api/v1/device/state','POST',{requestId:crypto.randomUUID(),payload:{sku:body.sku,device:body.device}});
   return respond(s,s.ok?200:502);
  }
  if(u.pathname==='/api/control'&&request.method==='POST'){
   const b=await request.json().catch(()=>null), c=b?.capability;
   if(!b||!isSku(b.sku)||!isDevice(b.device)||!c||!typeName(c.type)||!instanceName(c.instance)||!Object.hasOwn(c,'value'))return respond({ok:false,error:'Invalid control payload'},400);
   const r=await owned(env);if(!r.ok)return respond(r,502);
   const device=r.devices.find(x=>x.sku===b.sku&&x.device===b.device);
   if(!device)return respond({ok:false,error:'Device not registered to account'},403);
   const supported=(device.capabilities||[]).some(x=>x.type===c.type&&x.instance===c.instance);
   if(!supported)return respond({ok:false,error:'Capability not advertised by device'},400);
   // Safe subset. Extended scene-specific payloads require an explicit versioned approval.
   const allowed=['devices.capabilities.on_off','devices.capabilities.range','devices.capabilities.color_setting','devices.capabilities.color_temperature'];
   if(!allowed.includes(c.type))return respond({ok:false,error:'Capability not enabled in this version'},400);
   const out=await govee(env,'/router/api/v1/device/control','POST',{requestId:crypto.randomUUID(),payload:{sku:b.sku,device:b.device,capability:{type:c.type,instance:c.instance,value:c.value}}});
   return respond(out,out.ok?200:502);
  }
  return respond({ok:false,error:'Not found'},404);
 } catch(err){return respond({ok:false,error:'Request failed'},500);}
}};
