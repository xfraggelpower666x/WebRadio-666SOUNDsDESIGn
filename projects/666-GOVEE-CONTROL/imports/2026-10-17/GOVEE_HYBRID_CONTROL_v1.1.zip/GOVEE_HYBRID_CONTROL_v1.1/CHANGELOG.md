# v1.1
- H6047 Modell und H6198 Modell ergänzt; Router-IP und MAC beibehalten.
- H6198 LAN-Befehle gesperrt, statt Fehlversuche zu senden.
- Offizielle Govee-v1-Cloud-Geräteliste als READ-ONLY-Endpoint ergänzt.
- Schlüssel ausschließlich lokal / serverseitig, kein Schlüssel im Browser.
- Gemeinsame Steuerung nur für LAN-berechtigte Geräte.
- Keine automatische Cloud-Steuerung, keine Fremdprojektänderung.
