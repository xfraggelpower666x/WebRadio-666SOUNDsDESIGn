# 666 GOVEE HYBRID CONTROL v1.1 — Windows 11

## Was diese Version tatsächlich kann
- **H6047 LightBars** (`192.168.2.32`): bestehende LAN-Steuerung unverändert (UDP 4003). LAN-Befehle liefern keine Bestätigung des Geräteerfolgs.
- **H6198 TV** (`192.168.2.33`): **neue offizielle Cloud-Geräteabfrage**, noch **keine TV-Steuerbefehle**. Ohne LAN-Control-Schalter werden keine LAN-Befehle an das TV-Gerät gesendet.
- Gruppenaktionen gelten zunächst ausschließlich für LAN-freigegebene Geräte; so wird die TV-Synchronisation nicht versehentlich unterbrochen.

## Schnellstart
1. ZIP entpacken. Python 3 installieren, wenn noch nicht vorhanden.
2. `START_WINDOWS.bat` starten; Dashboard: `http://127.0.0.1:8766`.
3. Govee-Home-App: API-Key über Govee Developer API beantragen. Hinweise: https://developer.govee.com/docs/getting-started
4. In **diesem lokalen Programmordner** eine Datei `govee_api_key.txt` erstellen; **nur den eigenen Schlüssel** ohne zusätzliche Zeichen eintragen. Alternativ Umgebungsvariable `GOVEE_API_KEY` verwenden. Datei nicht teilen, nicht ins Repo/ZIP/Cloud hochladen. Nicht in HTML, Screenshots oder Chat einfügen.
5. Dashboard → **TV-Gerät abfragen**. Das Backend ruft `GET https://developer-api.govee.com/v1/devices` mit dem Schlüssel ausschließlich serverseitig über HTTPS auf.
6. Ergebnis prüfen: H6198, API-Geräte-ID, `controllable`, `retrievable`, `supportCmds`. Govee API-ID und Router-MAC können abweichen! **Nicht automatisch zuordnen.**

## Sicherheit
- HTTP-Server nur `127.0.0.1:8766`. Key bleibt lokal in TXT/Umgebungsvariable und wird nicht im HTML oder in der API-Ausgabe angezeigt.
- Die Govee-Cloud-Abfrage benötigt Internet; LightBars-LAN nicht. Keine Cloud-Write-API aktiviert, keine Hintergrundautomation, keine Audioeffekte.
- Projektordner **nicht** in ein öffentliches Git-Repository synchronisieren, wenn sich `govee_api_key.txt` darin befindet. `.gitignore` vorhanden.
- Die Govee-API-Version v1 ist der hier bewusst verwendete dokumentierte Discovery-Pfad; eventuelle Abschaltung/Änderung wird als HTTP-Fehler sichtbar, nicht als Geräteerfolg interpretiert.

## Verifikationsstatus
- VERIFIZIERT: Implementierung / lokale Endpoints und Tests (soweit im Testprotokoll beschrieben).
- OFFEN: echter Abruf beim Benutzer (Schlüssel fehlt hier), Hardware-Wirkung und Modell-Capabilities.

## Handoff
Source v1 erhalten; gezielte Änderung an `server.py`, `index.html`, `devices.json`. Kein Zugriff auf eine produktive GitHub-Repository erfolgt. Integration in 666 LIGHT ORCHESTRA SYMPHONY erst nach nativer Source-/Pointer-Prüfung.
Quellen: https://developer.govee.com/docs/support-product-model und https://govee-public.s3.amazonaws.com/developer-docs/GoveeAPIReference.pdf
