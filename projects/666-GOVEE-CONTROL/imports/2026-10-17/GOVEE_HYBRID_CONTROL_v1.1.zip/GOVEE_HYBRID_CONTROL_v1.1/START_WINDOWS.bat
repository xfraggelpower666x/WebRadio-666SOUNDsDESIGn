@echo off
cd /d "%~dp0"
where py >nul 2>&1
if %errorlevel%==0 (start "" "http://127.0.0.1:8766" & py -3 server.py & pause & exit /b)
where python >nul 2>&1
if %errorlevel%==0 (start "" "http://127.0.0.1:8766" & python server.py & pause & exit /b)
echo Python 3 ist nicht installiert. Bitte Python 3 installieren und erneut starten.
pause
