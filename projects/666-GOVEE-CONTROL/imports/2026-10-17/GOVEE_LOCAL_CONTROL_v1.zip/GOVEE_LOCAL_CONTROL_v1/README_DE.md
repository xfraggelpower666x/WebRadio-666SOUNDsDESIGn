# Govee Local Control v1.0

## Installation und Start (Windows 11)
1. ZIP entpacken. Python 3 installieren, falls noch nicht vorhanden (python.org). Keine externen Python-Pakete benötigt.
2. In der Govee-Home-App **bei beiden Geräten** prüfen, ob **LAN Control / LAN-Steuerung** vorhanden und aktiviert ist. Nicht jedes Govee-Modell unterstützt sie. Modellnummern (Hxxxx) hier noch unbekannt.
3. PC und Geräte im gleichen LAN/WLAN betreiben; Gastnetz/Client-Isolation vermeiden. Im Router sind die IP-Adressen bereits auf .32 und .33 fixiert.
4. `START_WINDOWS.bat` doppelklicken, dann `http://127.0.0.1:8766` öffnen. Das schwarze Konsolenfenster offen lassen.
5. **EIN** und **AUS** zunächst bei einer einzelnen Leuchte testen, anschließend Helligkeit, Farben und Gruppe.

## Sicherheit und Grenzen
- Nur auf 127.0.0.1 gebundener lokaler Webserver. Browser-Frontend kommuniziert mit lokalem Backend; Backend sendet JSON-UDP an Port **4003** der beiden explizit erlaubten IP-Adressen.
- Kein offenes Internet, keine Cloud, keine API-Tokens. LAN-Protokoll selbst ist unverschlüsselt und ohne Authentifizierung, daher nur in vertrauenswürdigem Netzwerk benutzen.
- **Befehl gesendet ≠ erfolgreich ausgeführt.** Der v1-Status sagt nur aus, dass das Betriebssystem das UDP-Datagramm angenommen hat; er behauptet keine Gerätebestätigung.
- Router-Signalqualität zeigt WLAN-Verbindung, beweist keine LAN-API-Unterstützung. MAC und IP identifizieren die Netzwerkverbindungen, nicht die H-Modellnummer.
- Farbtemperatur hängt von den Fähigkeiten des Modells ab; Geräte können Werte außerhalb ihres Spektrums ignorieren.
- Wenn das Gerät nicht reagiert: Govee-LAN-Schalter und Modell prüfen, PC-WLAN-Netz vergleichen, lokale Firewall/Isolation prüfen, Govee Desktop als Gegenprobe testen.
- `devices.json`: IP-Adressen und Anzeigenamen nach Bedarf anpassen; Server danach neu starten. Weitere Geräte nur mit bekannter, unterstützter IP hinzufügen.

## Architektur / Handoff
`index.html` → `POST /api/control` → `server.py` (Python-Standardbibliothek) → Govee LAN JSON UDP 4003 → LightBars `.32` / TV `.33`.
`GET /api/devices` liefert die aus `devices.json` konfigurierte Liste. Keine simulierten Zustände oder permanenten Effekte. Für Soundreaktivität wäre später ein eigenständiger Audioanalyse-Dienst + rate-limitiertes UDP-Protokoll nötig. Nicht ohne Prüfung der bestehenden LIGHT_ORCHESTRA-Architektur integrieren.

## Status
- **VERIFIZIERT:** Python-Implementierung kann syntaktisch / lokal HTTP geprüft werden.
- **OFFEN:** Gerätemodelle, LAN-Capability und tatsächlich ausgeführte Befehle auf der Hardware (aus dieser Umgebung nicht erreichbar).

Offizielle Spezifikation: https://app-h5.govee.com/user-manual/wlan-guide
