"""Lokales Govee-Dashboard. Python-Standardbibliothek; keine Cloud und keine Abhängigkeiten."""
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
import json, socket, threading, time, ipaddress, urllib.parse

ROOT = Path(__file__).resolve().parent
CONFIG = json.loads((ROOT/'devices.json').read_text(encoding='utf-8'))
DEVICES = {d['id']: d for d in CONFIG['devices']}
for d in DEVICES.values():
    ipaddress.IPv4Address(d['ip'])
LISTEN = '127.0.0.1'
PORT = 8766
LOCK = threading.Lock()
LAST = {}


def send_udp(ip, cmd, data):
    payload = json.dumps({'msg': {'cmd': cmd, 'data': data}}, separators=(',', ':')).encode()
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
        s.settimeout(1.0)
        s.sendto(payload, (ip, 4003))
    return {'sent': True, 'confirmed': False, 'note': 'UDP-Befehl versendet; keine Gerätebestätigung.'}


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        print('%s %s' % (self.address_string(), fmt % args))

    def reply(self, code, data):
        raw = json.dumps(data, ensure_ascii=False).encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(raw)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self):
        path = urllib.parse.urlsplit(self.path).path
        if path == '/api/devices':
            return self.reply(200, {'devices': CONFIG['devices'], 'last': LAST})
        if path in ('/', '/index.html'):
            raw = (ROOT/'index.html').read_bytes()
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.send_header('Content-Length', str(len(raw)))
            self.send_header('Content-Security-Policy', "default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; connect-src 'self'")
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.end_headers()
            return self.wfile.write(raw)
        return self.reply(404, {'error': 'Nicht gefunden'})

    def do_POST(self):
        if self.path != '/api/control':
            return self.reply(404, {'error': 'Nicht gefunden'})
        origin = self.headers.get('Origin')
        if origin and origin not in (f'http://127.0.0.1:{PORT}', f'http://localhost:{PORT}'):
            return self.reply(403, {'error': 'Ungültiger Origin'})
        try:
            size = int(self.headers.get('Content-Length', '0'))
            if not 0 < size <= 4096:
                raise ValueError('Ungültige Datenlänge')
            data = json.loads(self.rfile.read(size))
            ids = data.get('devices')
            if not isinstance(ids, list) or not ids or any(i not in DEVICES for i in ids) or len(ids) > len(DEVICES):
                raise ValueError('Unbekannte Geräte')
            ids = list(dict.fromkeys(ids))
            action = data.get('action')
            value = data.get('value')
            if action == 'turn' and type(value) is bool:
                cmd, payload = 'turn', {'value': int(value)}
            elif action == 'brightness' and type(value) is int and 1 <= value <= 100:
                cmd, payload = 'brightness', {'value': value}
            elif action == 'color' and isinstance(value, str) and len(value) == 7 and value[0] == '#' and all(c in '0123456789abcdefABCDEF' for c in value[1:]):
                cmd, payload = 'colorwc', {'color': {'r': int(value[1:3], 16), 'g': int(value[3:5], 16), 'b': int(value[5:7], 16)}, 'colorTemInKelvin': 0}
            elif action == 'temperature' and type(value) is int and 2000 <= value <= 9000:
                cmd, payload = 'colorwc', {'color': {'r': 0, 'g': 0, 'b': 0}, 'colorTemInKelvin': value}
            else:
                raise ValueError('Ungültiger Befehl oder Wert')
            results = []
            with LOCK:
                for device_id in ids:
                    device = DEVICES[device_id]
                    try:
                        outcome = send_udp(device['ip'], cmd, payload)
                        LAST[device_id] = {'action': action, 'value': value, 'at': time.strftime('%Y-%m-%d %H:%M:%S'), **outcome}
                        results.append({'id': device_id, **outcome})
                    except OSError as exc:
                        results.append({'id': device_id, 'sent': False, 'error': str(exc)})
                    time.sleep(0.035)
            return self.reply(200, {'results': results})
        except (ValueError, TypeError, json.JSONDecodeError) as exc:
            return self.reply(400, {'error': str(exc)})


if __name__ == '__main__':
    print(f'Govee Local Control: http://{LISTEN}:{PORT}')
    print('Nur lokal erreichbar. Zum Stoppen Strg+C drücken.')
    ThreadingHTTPServer((LISTEN, PORT), Handler).serve_forever()
